﻿// Skeleton implementation written by Joe Zachary for CS 3500, September 2013.
// Version 1.1 (Fixed error in comment for RemoveDependency.)
// Version 1.2 - Daniel Kopta 
//               (Clarified meaning of dependent and dependee.)
//               (Clarified names in solution/project structure.)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpreadsheetUtilities
{
    /// <summary> 
    /// Author:    Sasha Singh
    /// Partner:   None
    /// Date:      22nd-Jan-2022
    /// Course:    CS 3500, University of Utah, School of Computing 
    /// Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework. 
    /// 
    /// I, Sasha Singh, certify that I wrote this code from scratch and did not copy it in part or whole from  
    /// another source.  All references used in the completion of the assignment are cited in my README file. 
    /// 
    /// File Contents: DependencyGraph.cs which contains the overall program for 
    /// what a Dependenc Graph is and how it evaluates variables. 
    /// DependencyGrapthTests.cs which will contain a comprehensive list of tests
    /// to make sure that "cell values" are created/added correctly in a graph 
    /// and are able to ouptput values.
    /// 
    /// Project Details:
    /// (s1,t1) is an ordered pair of strings
    /// t1 depends on s1; s1 must be evaluated before t1
    /// 
    /// A DependencyGraph can be modeled as a set of ordered pairs of strings.  Two ordered pairs
    /// (s1,t1) and (s2,t2) are considered equal if and only if s1 equals s2 and t1 equals t2.
    /// Recall that sets never contain duplicates.  If an attempt is made to add an element to a 
    /// set, and the element is already in the set, the set remains unchanged.
    /// 
    /// Given a DependencyGraph DG:
    /// 
    ///    (1) If s is a string, the set of all strings t such that (s,t) is in DG is called dependents(s).
    ///        (The set of things that depend on s)    
    ///        
    ///    (2) If s is a string, the set of all strings t such that (t,s) is in DG is called dependees(s).
    ///        (The set of things that s depends on) 
    //
    // For example, suppose DG = {("a", "b"), ("a", "c"), ("b", "d"), ("d", "d")}
    //     dependents("a") = {"b", "c"}
    //     dependents("b") = {"d"}
    //     dependents("c") = {}
    //     dependents("d") = {"d"}
    //     dependees("a") = {}
    //     dependees("b") = {"a"}
    //     dependees("c") = {"a"}
    //     dependees("d") = {"b", "d"}
    /// </summary>
    public class DependencyGraph
    {
        //This class depends on imitating a graph using a Dicionary with a string
        //representing a key and it's values as a HashSet- a set of values.

        //Dependents Dictionary -which cell value depened on me. 
        Dictionary<string, HashSet<string>> dependents;


        //Dependees Dictionary- which cell values do I depend on.
        Dictionary<string, HashSet<string>> dependees;

        //Keep track of the size of a graph
        private int numberOfPairs;

        /// <summary>
        /// Constructor for the DependencyGraph class.
        /// Creates an empty DependencyGraph.
        /// </summary>
        public DependencyGraph()
        {
            dependents = new Dictionary<string, HashSet<string>>();
            dependees = new Dictionary<string, HashSet<string>>();
            numberOfPairs = 0;
        }


        /// <summary>
        /// The number of ordered pairs in the DependencyGraph.
        /// </summary>
        public int Size
        {
            get { return numberOfPairs; }
        }


        /// <summary>
        /// The size of dependees(s).
        /// This property is an example of an indexer.  If dg is a DependencyGraph, you would
        /// invoke it like this:
        /// dg["a"]
        /// It should return the size of dependees("a")
        /// </summary>
        public int this[string s]
        {
            get
            {
                if (dependents.ContainsKey(s))
                    return dependents[s].Count;
                else
                    return 0;
            }

        }


        /// <summary>
        /// Reports whether dependents(s) is non-empty.
        /// </summary>
        public bool HasDependents(string s)
        {
            //Checks if the dependees has the specific key but also that it's not an
            //empty set.
            return (dependees.ContainsKey(s) && dependees[s].Count > 0);

        }



        /// <summary>
        /// Reports whether dependees(s) is non-empty.
        /// </summary>
        public bool HasDependees(string s)
        {
            //Checks if the dependents has the specific key but also that it's not an
            //empty set.
            return (dependents.ContainsKey(s) && dependents[s].Count > 0);

        }


        /// <summary>
        /// Enumerates dependents(s).
        /// </summary>
        public IEnumerable<string> GetDependents(string s)
        {
            if (dependees.ContainsKey(s))
            {
                return new HashSet<string>(dependees[s]);
            }
            else
            {
                return Array.Empty<String>();
            }
        }

        /// <summary>
        /// Enumerates dependees(s).
        /// </summary>
        public IEnumerable<string> GetDependees(string s)
        {
            if (dependents.ContainsKey(s))
            {
                return new HashSet<string>(dependents[s]);
            }
            else
            {
                return Array.Empty<String>();
            }
        }

        /// <summary>
        /// <para>Adds the ordered pair (s,t), if it doesn't exist</para>
        /// 
        /// <para>This should be thought of as:</para>   
        /// 
        ///   t depends on s
        ///
        /// </summary>
        /// <param name="s"> s must be evaluated first. T depends on S</param>
        /// <param name="t"> t cannot be evaluated until s is</param>        /// 
        public void AddDependency(string s, string t)
        {
            if (!(dependees.ContainsKey(s) && dependents.ContainsKey(t) && dependees[s].Contains(t)))
            {
                numberOfPairs++;
            }
            if (dependees.ContainsKey((s)))
            {
                dependees[s].Add(t);
            }
            else
            {
                //not in the dictionary so create it.
                HashSet<string> dependentsOfS = new HashSet<string>();
                dependentsOfS.Add(t);
                dependees.Add(s, dependentsOfS);
            }

            if (dependents.ContainsKey(t))
            {
                dependents[t].Add(s);
            }
            else
            {
                //not in the dictionary so create it.
                HashSet<string> dependeesOfT = new HashSet<string>();
                dependeesOfT.Add(s);
                dependents.Add(t, dependeesOfT);
            }

        }


        /// <summary>
        /// Removes the ordered pair (s,t), if it exists
        /// </summary>
        /// <param name="s"></param>
        /// <param name="t"></param>
        public void RemoveDependency(string s, string t)
        {
            if (dependees.ContainsKey(s) && dependents.ContainsKey(t) && dependees[s].Contains(t))
            {
                numberOfPairs--;
            }

            if (dependees.ContainsKey(s))
            {
                dependees[s].Remove(t);
            }

            if (dependents.ContainsKey(t))
            {
                dependents[t].Remove(s);
            }
        }



        /// <summary>
        /// Removes all existing ordered pairs of the form (s,r).  Then, for each
        /// t in newDependents, adds the ordered pair (s,t).
        /// </summary>
        public void ReplaceDependents(string s, IEnumerable<string> newDependents)
        {
            //Obtain the existing dependents of s
            IEnumerable<string> existingDependents = GetDependents(s);

            //remove all the existing pairs with "r" as the values
            foreach (string r in existingDependents)
                RemoveDependency(s, r);

            //replace all old values of "s" with "t"
            foreach (string t in newDependents)
                AddDependency(s, t);

        }


        /// <summary>
        /// Removes all existing ordered pairs of the form (r,s).  Then, for each 
        /// t in newDependees, adds the ordered pair (t,s).
        /// </summary>
        public void ReplaceDependees(string s, IEnumerable<string> newDependees)
        {
            //Obtain the existing dependees of s
            IEnumerable<string> existingDependees = GetDependees(s);

            //remove all the existing pairs with "s" as the values
            foreach (string r in existingDependees)
                RemoveDependency(r, s);

            //replace all old values of "t" with "s"
            foreach (string t in newDependees)
                AddDependency(t, s);
        }

    }

}
