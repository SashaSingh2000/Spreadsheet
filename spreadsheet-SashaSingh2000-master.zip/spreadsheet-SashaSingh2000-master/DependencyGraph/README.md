﻿```
Author:    Sasha Singh
Partner:   None
Date:      22-Jan-2022 to Jan-28-2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh
Repo:      https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:  b6babb2bd157fefcf563c30b0804d4e510fbc69c
Project:   Dependency Graph
Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators + Assignment Specific Implementation:

1. The first thing that I wanted to do was explore some Data Structures that I could 
use to represent this diagram of dependents and dependees. 
From my understanding, Dependents can be described as, "which cell value depened on me". 
And Dependees can be described as, "which cell values do I depend on".
I then took a look at the example that was given in the documentaion. Basically you have 
strings of cell values, one is a key and it's value is a set of values. 
I did some research on fastest access, and then the differnce between HashMap Vs HashSets 
and then how do Dictionaries store information. I was able to find something that would
best fit my needs. 
"A HashSet, similar to a Dictionary, is a hash-based collection, so look ups are very 
fast with O(1). But unlike a dictionary, it doesn't store key/value pairs; 
it only stores values." 
Therefore, I have decided to make Dictionaries with string as the key, and HashSets as 
the value. 

2. I was having a hard time understanding the getDependants and getDependees methods 
and what would happen if the string itself was empty or null or if that specific string
wasn't found in the dictionary. TA Prajeet Vakiti was able to help me implement this method.
I was still a little bit confused as to how you could use an Array.Empty method but I think
for this program you just return something that is empty. 

3. I was having quite a few problems with adding and removing dependencies- I was able to
work with a TA to fix some of the issues but I am still not sure what happens if you delete a
value a specific key holds. Does it delete the entire hashset or just the specified value?

4. I kept failing the simplest of the add and remove tests and it kept saying, that a key 
exsisted already. I wasn't sure exactly sure why this was, turns out I wasn't adding to the 
right key. 

5. My final concerns were resolved by TA Cayden. He was able to help me understand the 
Remove and Add method. My underdstandins is that, "If t depends on s then the dependees of t
is s and depdendants of s is t."

# Consulted Peers:

-Sana Kureshi -enumerator testing
-Gabriel Famudo -replace method
-Shadee Perez -remove method


# References:
1. Difference Between HashSet and HashMap- https://www.geeksforgeeks.org/difference-between-hashmap-and-hashset/
2. 5 C# Collections that Every C# Developer Must Know- https://programmingwithmosh.com/net/csharp-collections/
3. Array.Empty<T> Method- https://docs.microsoft.com/en-us/dotnet/api/system.array.empty?view=net-6.0
4. IEnumerable in C#- https://www.c-sharpcorner.com/UploadFile/0c1bb2/ienumerable-interface-in-C-Sharp/
5. HashSet<T>.Add(T) Method- https://docs.microsoft.com/en-us/dotnet/api/system.collections.generic.hashset-1.add?view=net-6.0
6. HashSet<T>.Contains(T) Method- https://docs.microsoft.com/en-us/dotnet/api/system.collections.generic.hashset-1.contains?view=net-6.0


# Time Spent:

    Overall time estimate - 10 hours in the span of 7 days.

    Actual Number of hour spent: 
    January 22nd - 1.5 hours -setup
    January 23rd - 1 hour 
    January 25th - 2 hours
    January 26th - 1.5 hours
    January 27th- 2 hours
    January 28thth - 3 hours

    Total Time: 11 hours