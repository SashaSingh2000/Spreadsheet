﻿using FormulaEvaluator;
using System;

namespace Test_The_Evaluator_Console_App
{
    /// <summary>
    /// Author:    Sasha Singh
    /// Partner:   None
    /// Date:      13th-Jan-2022
    /// Course:    CS 3500, University of Utah, School of Computing 
    /// Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework. 
    /// 
    /// I, Sasha Singh, certify that I wrote this code from scratch and did not copy it in part or whole from  
    /// another source.  All references used in the completion of the assignment are cited in my README file. 
    /// 
    ///This is a console tester for Formula Evaluator and will contain all terminal line
    ///testing.
    /// </summary>
    class EvaluatorTest
    {
        static void Main(string[] args)
        {

            // addition
            Console.WriteLine($"Evaluate 1+1 : {Evaluator.Evaluate("1+1", null)}");


            //subtraction
            Console.WriteLine($"Evaluate 100000 - 1 = {Evaluator.Evaluate("100000 - 1", null)}");


            //multiplication
            Console.WriteLine($"Evaluate 4263*0 = {Evaluator.Evaluate("4263*0", null)}");


            //division
            Console.WriteLine($"Evaluate 90/3 = {Evaluator.Evaluate("90/3", null)}");

            //paranthesis
            Console.WriteLine($"Evaluate (6+4)+4 = {Evaluator.Evaluate("(6+4)+4", null)}");
            Console.WriteLine($"Evaluate (2)+ (2) = {Evaluator.Evaluate("(2)+(2)", null)}");



            //complex addition, subtraction, divison, and multiplication, paranthesis

            Console.WriteLine($"Evaluate 4 * 6 + 3 = {Evaluator.Evaluate("4 * 6 + 3", null)}");

            Console.WriteLine($"Evaluate 2+3*(3+2)= {Evaluator.Evaluate("2+3*(3+2)", null)}");

            //Console.WriteLine($"Evaluate 2+3*4+(3+4+8)*5*2= {Evaluator.Evaluate("2+3*4+(3+4+8)*5*2", null)}");

            Console.WriteLine($"Evaluate 2 + (6 + 5 * 3) = {Evaluator.Evaluate("2 + (6 + 5 * 3)", null)}");

            Console.WriteLine($"Evaluate 2 + 6 / 3 = {Evaluator.Evaluate("2 + 6 / 3", null)}");

            Console.WriteLine($"Evaluate 5 + (5+5) * 10 = {Evaluator.Evaluate("5 + (5+5) * 10", null)}");

            Console.WriteLine($"Evaluate (2 + 3) * 5 + 4 = {Evaluator.Evaluate("(2 + 3) * 5 + 4", null)}");

            Console.WriteLine($"Evaluate 8-2+(3*4)/2*2 = {Evaluator.Evaluate("8-2+(3*4)/2*2", null)}");

            Console.WriteLine($"Evaluate ((10-5)*2)/5 = {Evaluator.Evaluate("((10-5)*2)/5", null)}");


            //Exception Tests

            //division by Zero
            try
            {
                Evaluator.Evaluate("(4 * 2) / (4 - 4) ", null);
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine("Evaluate (4 * 2) / (4 - 4) : " + ex.Message);
                
            }

            //empty string
            try
            {
                Evaluator.Evaluate("", null);
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine("Evaluate empty string: " + ex.Message);
            }

            //empty paranthesis
            try
            {
                Evaluator.Evaluate("()", null);
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine("Evaluate () : " + ex.Message);
            }

            //operator
            try
            {
                Evaluator.Evaluate(" + ", null);
            }
            catch (ArgumentException ex)
            {
              Console.WriteLine("Evaluate + : " + ex.Message);
            }

            //operator
            try
            {
                Evaluator.Evaluate("3+5+ ", null);
            }
            catch (ArgumentException ex)
            {
              Console.WriteLine("Evaluate 3+5+ : " + ex.Message);
            }

            //paranthesis
            try
            {
                Evaluator.Evaluate("5+7+(5)8 ", null);
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine("Evaluate 5+7+(5)8 : " + ex.Message);
            }

            //complex computation
            try
            {
                Evaluator.Evaluate(" 5 + 3 * 7 – 8 / (4 + 3) – 2 / 2", null);
            }
            catch(ArgumentException ex)
            {
                Console.WriteLine("Evaluate  5 + 3 * 7 – 8 / (4 + 3) – 2 / 2 : " + ex.Message);
            }

            //Variable checks
            Console.WriteLine($"Evaluate A1 : {Evaluator.Evaluate("A1", lookUpVar)}");
            Console.WriteLine($"Evaluate ABCD789 : {Evaluator.Evaluate("ABCD789", lookUpVar)}");
            Console.WriteLine($"Evaluate z4 : {Evaluator.Evaluate("z4", lookUpVar)}");

            //Variable Exceptions
            try
            {
                Evaluator.Evaluate("a1", lookUpVar);
            }
            catch (ArgumentException ax)
            {
                Console.WriteLine("Evaluate a1 : " + ax.Message);               
            }

            try
            {
                Evaluator.Evaluate("B2", lookUpVar);
            }
            catch (ArgumentException ax)
            {
                Console.WriteLine("Evaluate B2 : " + ax.Message);
            }

            //Variable and Integer tests
            Console.WriteLine($"Evaluate 2 + 6 + A1= {Evaluator.Evaluate("2 + 6 + A1", lookUpVar)}");
            Console.WriteLine($"Evaluate 3*6 * AA1 = {Evaluator.Evaluate("3*6 * AA1 ", lookUpVar)}");
            Console.WriteLine($"Evaluate 2 + z4 = {Evaluator.Evaluate("2 + z4", lookUpVar)}");
            Console.WriteLine($"Evaluate 8-2+(3*a9)/2*2 = {Evaluator.Evaluate("8-2+(3*a9)/2*2", lookUpVar)}");
        }
        /// <summary>
        /// A lookup function to pass in as a delegate to obtain the value 
        /// of a variable token.
        /// </summary>
        /// <param name="variableToCheck"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        private static int lookUpVar(String variableToCheck)
        {
            switch (variableToCheck)
            {
                case "A1":
                    return 10;
                case "AA1": 
                    return 2;
                case "ABCD789":
                    return 6;
                case "B1": 
                    return 0;
                case "a9":
                    return 20;
                case "z4":
                    return 20;
            }
            //if looking up a variable, doesn't return a value- the delegate throws!
            throw new ArgumentException("Looking up variable reveals it has no value");
        }

    }
}

