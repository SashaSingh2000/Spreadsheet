﻿```
Author:    Sasha Singh
Partner:   None
Date:      19-Jan-2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh
Repo:      https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:  ef12134bb0c689918db2d621fda0edc514e43e8f
Project:   Formula Evaluator
Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators + Assignment Specific Implementation:

1) For this assignment, I wanted to do a comprehensive set of testing, especially because we haven't
covered Unit tetsing as of yet. I decided to seperate tests into 5 sections:
a) Simple addition, subtraction, division, multiplication, paranthesis, and white spaces
b) Complex addition, subtraction, division, multiplication, paranthesis, and white spaces
c) Simple and Complex variable tests
d) Combination of Variable and Integer testing
e) Exception types- division by zero, value stack empty, empty string, single operator, etc.

2) I had a dew issues testing for division by zero and instead of getting an error,
was getting "0" as the answer. I took some time to run the debugger and figure out why this
was. After fixing the problem in the code, I was able to catch division by zero exceptions.

3) I consulted few TA's about the structure of my tester code. I considered putting them all
in their own Unit Test Methods. But I was given the advice that for this assignment, that
for this assignment the way my tests are set up are fine.
TA Tanuja was able to help me make the lookupVar method to pass in as a delegate.


# Consulted Peers:

TA Ben Essex
TA Tanuja Pandian
TA Tyler Grant

# References:

    1. Catching errors for testing: https://piazza.com/class/ky9bacgwi1q3sn?cid=128
    2. Delegates FAQ: https://piazza.com/class/ky9bacgwi1q3sn?cid=120
    3. Testing Format: https://piazza.com/class/ky9bacgwi1q3sn?cid=112

# Time Spent:

    Time Spent testing - 4 hours