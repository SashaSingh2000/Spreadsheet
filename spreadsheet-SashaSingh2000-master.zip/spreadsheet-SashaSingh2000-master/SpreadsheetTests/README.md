﻿```
 Author:   Sasha Singh
Partner:   None
Date:      Feb-6-2022 to Feb-19-2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh
Repo:      https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:  d1f65648ef49e930ae5d9c0d23df5fd2214721c8
Project:   Abstract Spreadsheet
Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators + Assignment Specific Implementation:

This tester file will tests roughly around the following questions addressed in Lab 5 this week:

How will you store cells?  Where will you store them?
How will you differentiate between empty and non-empty cells?
What should the SetCellContents methods return and why?
How will you implement returning the data discussed above?
What happens when the user tries to create a circular dependency?
How do you create tests for the Spreadsheet?
Where do you need to store and compute the value of formulas?

Tests for each method being null or empty or invalid.

Piazza Posts were inspiration for many tests and some from the Grading Test of A4


# Consulted Peers:


# References:

1.https://piazza.com/class/ky9bacgwi1q3sn?cid=461
2.Coverage Report- file:///C:/Users/u0982683/source/repos/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000/SpreadsheetTests/coveragereport/Spreadsheet_Spreadsheet.html
3. XML Tests adopted from Prof Germain and Kopta.

# Time Spent:

    Time Spent testing - 1 hour
    Time Spent Tetsing As5: 3 hours
   
