﻿```
Author:    Sasha Singh
Partner:   None
Date:      13-Jan-2022- 21-Jan-2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh
Repo:      https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:  129a9051a9a8991353ff93688bc34e1b9f67b412
Project:   Formula Evaluator
Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators + Assignment Specific Implementation:

1) Having taken this class in the past, I was able to recall a common code repition which was 
related to looking at the top of a stack to see what operator was at the top.
In order to perform a peek information, you have to make sure that there is something at the top
of the stack and that it isn't empty. Now, to avoid repeating this code each time we do a peek
operation- I chose to make a Stack Extension method. From my understand an extension method is 
basically syntactic sugar that "adds" an extra method to that specific class without actually 
modifying it. This method is called "onTopOfStack" and is within the same namespace. 
This method/code design was adopted from Dr. Daniel Kopta from CS 3500 in Fall 2021.

2)Another helper method that has been added to this code is to make calculations easier.
Depending on the operator that is in the middle of two numbers- either multiplication, 
division,addition, or subtraction will be performed. So wherever we are required to push 
a result onto the value stack- this helper method will be called and 
the calculation will be performed and pushed onto the value stack.

3) Initially I thought that both Stacks would contain String types- but looking at some of the 
conditions that check for a token to be an integer and then having to pop those values and
make a calculation- there would have been too many conversions/casts happening. So I decided
to make the Values Stack integer types.

4) Afer a few rounds of debugging and adding certain error handling code, I ran into a problem
to do with empty strings as tokens. After some research and advice from Dr.de St. Germain- I ran
into the problem that "If multiple matches are adjacent to one another, an empty string is inserted 
into the array." From what I understand when I am testing for "(5+5) * 10"- it is breaking the substring
into tokens that contain an empty space as the very first token. The suggestion to fix the problem was
to try and "test something like: if (substring != String.Empty)". I don't think this is necessarily
something that needs to be handeled, because an empty string means nothing to the program.

5) The very last thing I took care of after I made sure integer testing was fully function
was to check for when token is a variable. I had a lot of thoughts on this and how I want to
make the simple check of a string letter followed by an integer digit. I initially wanted
to try using characters IsLetter and IsDigit methods but that seemed to not cover some edge-case.
I finally decided to just create a Regex, for any number of lower/upper case letters
followed by any number of digits. 

# Consulted Peers:

I discussed code design with Jerry Su, Jonny Evans, and Tyler Porter in my lab!

# References:

    1. Remove Whitespace from C# Strings - https://www.csharp411.com/remove-whitespace-from-c-strings/
    2. Switch Statements in C# - https://www.geeksforgeeks.org/switch-statement-in-c-sharp/#:~:text=In%20C%23%2C%20Switch%20statement%20is,type%2C%20or%20of%20string%20type
    3. Extension Methods - https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/classes-and-structs/extension-methods
    4. Stack - https://docs.microsoft.com/en-us/dotnet/api/system.collections.stack?view=net-6.0
    5. How to check if a string is a number in C# - https://www.arungudelli.com/tutorial/c-sharp/check-if-string-is-number/
    6. C# regex.split method is adding empty string before parenthesis- https://stackoverflow.com/questions/6619223/c-sharp-regex-split-method-is-adding-empty-string-before-parenthesis
    7. Regex Code That is Provided (56) - https://piazza.com/class/ky9bacgwi1q3sn?cid=56
    8. “c# check if string is only letters and numbers” - https://www.codegrepper.com/code-examples/csharp/c%23+check+if+string+is+only+letters+and+numbers
    9. Regex.IsMatch Method- https://docs.microsoft.com/en-us/dotnet/api/system.text.regularexpressions.regex.ismatch?view=net-6.0
    10. Regex- https://docs.microsoft.com/en-us/dotnet/api/system.text.regularexpressions.regex?view=net-6.0
    11. Regular Expressions 101- https://regex101.com/

# Time Spent:

    Overall time estimate - 10 hours in the span of 7 days.
    January 13th - 1.5 hours
    January 15th - 3 hours
    January 16th - 1.5 hours
    January 17th - 2 hours
    January 18th- 2 hours -debugging
    January 19th - 2 hours -debugging
    January 20th- 4 hour  -testing
    January 21st - 2 hours -finishing touches

    Actual Number of hour spent: 18