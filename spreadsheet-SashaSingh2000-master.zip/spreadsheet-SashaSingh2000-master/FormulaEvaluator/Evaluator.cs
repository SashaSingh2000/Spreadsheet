﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Extensions;

namespace FormulaEvaluator
{
    /// <summary>
    /// Author: Sasha Singh
    /// Partner: -none-
    /// Date January 13th-January 21st, 20211
    /// Course: CS 3500
    /// 
    /// Project Description: This program evaluates integer arithmetic expressions written
    /// using standard infix notation. It respects the usual precedence rules and integer
    /// arithmetic. For example, if the input is "(2 + 3) * 5 + 2", the result is 27. 
    /// If the input is "(2 + X1) * 5 + 2", the result of course depends on the value of the 
    /// variable X1.If X1 is 7, for example, the result should be 47.
    /// 
    /// Note: The only legal tokens are the four operator symbols: + - * /,
    /// left parentheses, right parentheses, non-negative integers, whitespace, 
    /// and variables consisting of one or more letters followed by one or more digits.
    /// Letters can be lowercase or uppercase. 
    /// 
    /// I, Sasha Singh, certify that any code written in these files is written by me and only me.
    /// If I research anything, those sources will be cited specifically in the README 
    /// and not be plagarized.
    /// </summary>
    public class Evaluator
    {
        /// <summary>
        /// Private helper method to help with performing the correct calculation based on which
        /// operator is associated with the two values in the expression.
        /// </summary>
        /// <param name="operators"></param>
        /// <param name="leftValue"></param>
        /// <param name="rightValue"></param>
        /// <returns></returns>
        private static int valueCalculation(string operators, int leftValue, int rightValue)
        {
            switch (operators)
            {
                case "+":
                    return leftValue + rightValue;

                case "-":
                    return leftValue - rightValue;

                case "*":
                    return leftValue * rightValue;

                default:
                    return leftValue / rightValue;

            }
        }

        /// <summary>
        /// Given a variable name as its parameter, the delegate will either return an int 
        /// (the value of the variable) or throw an ArgumentException (if the variable 
        /// has no value).
        /// </summary>
        /// <param name="variable_name"></param>
        /// <returns></returns>
        public delegate int Lookup(String variable_name);

        /// <summary>
        /// Evaluate takes two parameters. 
        /// The first is the expression to be evaluated, and the second is a delegate
        /// that you can use to look up the value of a variable.
        /// </summary>
        /// <param name="expression"></param>
        /// <param name="variableEvaluator"></param>
        /// <returns></returns>
        public static int Evaluate(String expression, Lookup variableEvaluator)
        {
            //split a string into tokens
            string[] substrings = Regex.Split(expression, "(\\()|(\\))|(-)|(\\+)|(\\*)|(/)");

            Stack<String> operators = new Stack<String>();
            Stack<int> values = new Stack<int>();
            int result = 0;

            foreach (string s in substrings)
            {
                //trim the given string to remove white spaces
                string token = s.Trim();

                //regex to match when a token is a variable
                Regex variableRX = new Regex(@"^[a-zA-Z]+[0-9]+$");

                //CONDITION: t is an integer
                int numericValue;
                bool isInteger = int.TryParse(token, out numericValue);
                if (isInteger == true)
                {
                    //If * or / is at the top of the operator stack, pop the value stack,
                    //pop the operator stack, and apply the popped operator to the popped number and t.
                    //Push the result onto the value stack. Otherwise, push t onto the value stack.
                    if (operators.onTopOfStack("*") || operators.onTopOfStack("/"))
                    {
                        if (values.Count >= 1)
                        {
                            int leftValue = values.Pop();
                            string oper = operators.Pop();
                            if (oper.Equals("/") && numericValue == 0)
                            {
                                //A division by zero occurs.
                                throw new ArgumentException("A division by 0 has occured");
                            }

                            result = valueCalculation(oper, leftValue, numericValue);
                            values.Push(result);

                        }
                        else
                        {
                            //EXCEPTIONS:The value stack is empty. 
                            throw new ArgumentException("The value stack is empty");
                        }
                    }
                    else
                    {
                        values.Push(numericValue);
                    }
                }

                //CONDITION: t is a variable
                else if(variableRX.IsMatch(token)) {

                    //Proceed as above, using the looked-up value of t instead of t.
                    //EXCEPTIONS: If looking up t reveals it has no value(the delegate throws).
                    int variableLookup = variableEvaluator(token);

                //If * or / is at the top of the operator stack, pop the value stack,
                //pop the operator stack, and apply the popped operator to the popped number
                //and t. Push the result onto the value stack. Otherwise, push t onto the value
                //stack.
                if (operators.onTopOfStack("*")|| operators.onTopOfStack("/"))
                 {
                     if (values.Count >= 1)
                     {
                         int rightValue = values.Pop();
                         string oper = operators.Pop();
                            if(oper.Equals("/") && variableLookup == 0)
                            {
                                throw new ArgumentException("A division by zero has occured");
                            }
                         result = valueCalculation(oper, rightValue, variableLookup);
                         values.Push(result);
                        }
                        else
                        {
                            throw new ArgumentException("The value stack is empty.");
                        }
                 }
                 else
                 {
                     values.Push(variableLookup);
                 }
             }

                //CONDITION: t is + or -	
                else if (token.Equals("+") || token.Equals("-"))
                {
                    //If + or - is at the top of the operator stack, pop the value stack twice and
                    //the operator stack once, then apply the popped operator to the popped numbers,
                    //then push the result onto the value stack. Push t onto the operator stack
                    if (operators.onTopOfStack("+") || operators.onTopOfStack("-"))
                    {
                        if (values.Count >= 2)
                        {
                            int rightValue = values.Pop();
                            int leftValue = values.Pop();
                            string oper = operators.Pop();
                            result = valueCalculation(oper, leftValue, rightValue);
                            values.Push(result);

                        }
                        else
                        {
                            //EXCEPTION: The value stack contains fewer than 2 values if trying to pop it.
                            throw new ArgumentException("The value stack contains fewer than 2" +
                                " values when trying to pop it.");
                        }
                    }
                    operators.Push(token);
                }

                //CONDITION: t is * or /	
                //Push t onto the operator stack
                else if (token.Equals("*") || token.Equals("/"))
                {
                    operators.Push(token);
                }

                //CONDITION: t is a left parenthesis "("	
                //Push t onto the operator stack
                else if (token.Equals("("))
                {
                    operators.Push(token);
                }

                //CONDITION: t is a right parenthesis ")"	
                else if (token.Equals(")"))
                {
                    //If + or - is at the top of the operator stack, pop the value stack twice and
                    //the operator stack once. Apply the popped operator to the popped numbers.
                    //Push the result onto the value stack.
                    if (operators.onTopOfStack("+") || operators.onTopOfStack("-"))
                    {
                        if (values.Count >= 2)
                        {
                            int rightValue = values.Pop();
                            int leftValue = values.Pop();
                            string oper = operators.Pop();
                            result = valueCalculation(oper, leftValue, rightValue);
                            values.Push(result);

                        }
                        else
                        {
                            //EXCEPTION: The value stack contains fewer than 2 values during the first step.
                            throw new ArgumentException("The value stack contains fewer than 2 values during the first step.");
                        }
                    }
                    //Next, the top of the operator stack should be a '('.Pop it.
                    if (operators.onTopOfStack("("))
                    {
                        operators.Pop();
                    }
                    else
                    {
                        //EXCEPTION: A '(' isn't found where expected.
                        throw new ArgumentException("A '(' isn't found where expected.");
                    }
                    //Finally, if *or / is at the top of the operator stack, pop the value stack twice
                    //and the operator stack once. Apply the popped operator to the popped numbers.
                    //Push the result onto the value stack.
                    if (operators.onTopOfStack("*") || operators.onTopOfStack("/"))
                    {
                        if (values.Count >= 2)
                        {
                            int rightValue = values.Pop();
                            int leftValue = values.Pop();
                            string oper = operators.Pop();
                            if (oper.Equals("/") && rightValue == 0)
                            {
                                //A division by zero occurs
                                throw new ArgumentException("A division by zero occured");

                            }
                            else
                            {
                                result = valueCalculation(oper, leftValue, rightValue);
                                values.Push(result);
                            }
                        }
                        else
                        {
                            //EXCEPTION: The value stack contains fewer than 2 values during the final step.
                            throw new ArgumentException("The value stack contains fewer than 2 values");
                        }
                    }
                }
            }
            //When the last token has been processed:

            //CONDITION:Operator stack is empty
            //Value stack should contain a single number.
            //Pop it and report as the value of the expression
            if (operators.Count == 0)
            {
                if (values.Count == 1)
                {
                    result = values.Pop();
                }

                else
                {
                    //EXCEPTIONS: There isn't exactly one value on the value stack
                    throw new ArgumentException("There isn't exactly one value on the value stack");
                }

            }

            //CONDITION: Operator stack is not empty
            else if (operators.Count > 0)
            {
                //There should be exactly one operator on the operator stack,
                //and it should be either + or -.
                //There should be exactly two values on the value stack.Apply the operator
                //to the two values and report the result as the value of the expression.
                if (values.Count == 2)
                {
                    if (operators.Count == 1 && (operators.onTopOfStack("+") || operators.onTopOfStack("-")))
                    {
                        int rightValue = values.Pop();
                        int leftValue = values.Pop();
                        string oper = operators.Pop();
                        result = valueCalculation(oper, leftValue, rightValue);
                    }
                    else
                    {
                        throw new ArgumentException("There isn't exactly one operator on the operator stack");
                    }
                }//EXCEPTIONS: There isn't exactly two numbers on the value stack
                else
                {
                    throw new ArgumentException("There isn't exactly two numbers on the value stack");

                }
            }

            return result;
        }
    }
}
