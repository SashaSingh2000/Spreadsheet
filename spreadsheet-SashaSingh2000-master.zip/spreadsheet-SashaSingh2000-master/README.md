```
Author:    Sasha Singh
Partner:   None
Date:      13-Jan-2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh2000
Repo:       https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:   163353bccd8d789006854b740a758baa349f25b2
Solution:   Spreadsheet
Copyright:  3500, Sasha Singh- This work is solely mine and any template used here belongs to this class.
```

# Overview of the Spreadsheet functionality

This spreadsheet program is currently capable of evaluating formulas given integer and 
cell values. The program evaluates integer arithmetic expressions written 
using standard infix notation. The program also calculates cell dependencies, it addresses
the order in which variables need to be calculated and updates values accordingly. This program can also make sure 
that each variable is normalized to UpperCase and that a formula is valid and able to perform calculations
while keeping check of division by zero or invalid variables.
Future extensions will be building the Graphical User Interface, and perhaps even data visulization tools.

# Time Expenditures:

    1. Assignment One:   Predicted Hours:          10        Actual Hours:       18
    2. Assignment Two:   Predicted Hours:          10        Actual Hours:       11 
    3. Assignment Three: Predicted Hours:          15        Actual Hours:       18-20
    4. Assignment Four:  Predicted Hours:          10        Actual Hours:       12
    5. Assignment Five:  Predicted Hours:          15        Actual Hours:       15

