```
 Author:   Sasha Singh
Partner:   None
Date:      22-Jan-2022 to Jan-28-2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh
Repo:      https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:  129a9051a9a8991353ff93688bc34e1b9f67b412
Project:   Dependency Graph
Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators + Assignment Specific Implementation:

1. This Test class contains 6 additional tests that cover the "This", HasDependent, and 
   HasDependee methods. The code coverage and branch coverage is at a 100 percent. 

2. I got some pointers from TA Chris about Short Circuits in Testing. 
   He explained to me that, Short-circuit is a tricky method for evaluating 
   logical operators AND and OR. In this method, the whole expression can be evaluated to
   true or false without evaluating all sub expressions. This was what was happening in my 
   HasDependent and HasDependee methods. I have two checks- one has to do with the keys but 
   also a check to make sure that set isn't empty. My tests were not covering the second part
   of the if statement, therefore I added a simple check for both with an empty graph.


# Consulted Peers:

TA Christopher De-freitas

# References:

1. Short-Circuit Evaluation In C#- https://www.c-sharpcorner.com/article/short-circuit-evaluation-in-c-sharp/
2. Code Coverage Report- file:///C:/Users/u0982683/source/repos/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000/DependencyGraphTests/coveragereport/index.html


# Time Spent:

    Time Spent testing -
    January 26th- 1 hour
    January 27th - 1 hour
    January 28th - 2 hours
