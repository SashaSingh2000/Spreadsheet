﻿```
Author:    Sasha Singh
Partner:   None
Date:      30-Jan-2022 to Feb-4-2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh
Repo:      https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:  8ddf82ee12c1337e221f5ac57f1f29c6cb1ac80b
Project:   Formula
Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators + Assignment Specific Implementation:

There were quite a few issues in my code and a major gap in understanding of some methods that led me to need a lot of help on simple logical problems. 

1. I took a lot of time trying to construct a formula the right way. I had a hard time understanding how you would keep tracking of the previous tokens and check to see if they were numbers or variables or closing or opening parenthesis. I was able to ask a TA from a different class for help on this. She suggested that I do a simple flag check of what exactly the previous token was. Either it was a number, variable, or closing parenthesis OR it was an opening parenthesis or operator. This was a significant step in the right direction for me and she helped me reason through the process.
I implemented this in my code and found quite a few bugs and some missing parsing rule checks. I did have a hard time normalizing variables and where to do that and how to track all of that.

2. There were quite a few times that I wanted to normalize variables in toString or Equals but decided to stick doing everything in the constructor since that would actually have a normalizer and validator in it.
I was not checking for valid tokens at the right spot and so decided to move that check to the very top as soon as I was looking at a specific token, I would check if it is valid and if it was then only proceed with the algorithm. 
I also had a hard time thinking of where exactly I should check for an operator always being in a formula.


3. My initial thoughts had been to only have one list that contains all the tokens but it became very hard to keep track of regular tokens vs normalized variable tokens and so TA Tanuja suggested an extra list that would hold variables.
4. TA Prajeet helped me think about what it would take to make something immutable and I decided to use the ReadOnly keyword and the private access modifier. 
5. TA Santosh helped me think of a more concise way to work through toString- to only worry about normalizing variables and not other tokens.
6. I removed all ArgumentExceptions from the Evaluate method and only worried about returning FormulaErrors when division by zero occurred or a token was invalid. 
Had some issues with my HashCode method mainly because of my toString and once that was fixed- it was able to obtain the right hashcodes for formulas I was testing.
7. VariableChecker Helper Method + GetVariables() - TA Tanuja

8. I have been working on improving my code to fix errors and pass all grading tests but I see that I am still failing 3 due to some data structure choices.
I had origianlly decided to use two Lists but because some tests are written to check for duplicates, it would make more sense to use a HashSet instead- 
because they automatically eliminate duplicates. This would change the structure of my program a bit and I will try to pursue this further with 
Dr. Germain. 

9. This project is now fully functional with the help of Dr. de St Germain- I was able to debug the last failed test case.


# Consulted Peers:
Design details discusses with the following peers: Jonny Evans, Abhiveer Sharma, Sanjay Gounder, Sneha Raju, and Jerry Su.
TA's: Chris, Tanuja, Prajeet, Santosh, Narayani Archunan (1410)

# References:

1. Double.TryParse Method - https://docs.microsoft.com/en-us/dotnet/api/system.double.tryparse?view=net-6.0
2. All About C# Immutable Classes- https://www.c-sharpcorner.com/article/all-about-c-sharp-immutable-classes2/
3. is operator (C# reference)- https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/operators/is
4. Difference Between Equality Operator (==) and Equals() Method in C#- https://www.c-sharpcorner.com/UploadFile/3d39b4/difference-between-operator-and-equals-method-in-C-Sharp/#:~:text=The%20Equality%20Operator%20(%20%3D%3D)%20is,string%20variable%20to%20another%20variable
5. Week 3, Lecture 6- https://utah.instructure.com/courses/717551/pages/week-3-lectures?module_item_id=15926782

# Time Spent:

    Overall time estimate - 15 hours in the span of 6 five days.

    Actual Number of hour spent: 
    January 30th- 2 hours
    Feburary 2nd- 4 hours
    Feburary 3rd- 4 hours
    Feburary 4th- 8 hours

    Total Time: 18 hours
