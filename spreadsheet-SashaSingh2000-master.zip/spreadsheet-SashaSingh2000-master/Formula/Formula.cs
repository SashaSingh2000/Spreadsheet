﻿// Skeleton written by Joe Zachary for CS 3500, September 2013
// Read the entire skeleton carefully and completely before you
// do anything else!

// Version 1.1 (9/22/13 11:45 a.m.)

// Change log:
//  (Version 1.1) Repaired mistake in GetTokens
//  (Version 1.1) Changed specification of second constructor to
//                clarify description of how validation works

// (Daniel Kopta) 
// Version 1.2 (9/10/17) 

// Change log:
//  (Version 1.2) Changed the definition of equality with regards
//                to numeric tokens


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Extensions;


namespace SpreadsheetUtilities
{

    /// <summary>
    /// Author:    Sasha Singh
    /// Partner:   None
    /// Date:      30th-Jan-2022
    /// Course:    CS 3500, University of Utah, School of Computing 
    /// Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework. 
    /// 
    /// I, Sasha Singh, certify that I wrote this code from scratch and did not copy it in part or whole from  
    /// another source.  All references used in the completion of the assignment are cited in my README file. 
    /// 
    /// File Contents: Formula.cs which contains the overall program for 
    /// what a valid Formula is and what it evaluates to.
    /// FormulaTests.cs which will contain a comprehensive list of tests
    /// to make sure that Formula's are evaluated correctly according to valid rules.
    /// 
    /// Formula's are written in standard infix notation using standard precedence
    /// rules.  The allowed symbols are non-negative numbers written using double-precision 
    /// floating-point syntax (without unary preceeding '-' or '+'); 
    /// variables that consist of a letter or underscore followed by 
    /// zero or more letters, underscores, or digits; parentheses; and the four operator 
    /// symbols +, -, *, and /.  
    /// 
    /// Spaces are significant only insofar that they delimit tokens.  For example, "xy" is
    /// a single variable, "x y" consists of two variables "x" and y; "x23" is a single variable; 
    /// and "x 23" consists of a variable "x" and a number "23".
    /// 
    /// Associated with every formula are two delegates:  a normalizer and a validator.  The
    /// normalizer is used to convert variables into a canonical form, and the validator is used
    /// to add extra restrictions on the validity of a variable (beyond the standard requirement 
    /// that it consist of a letter or underscore followed by zero or more letters, underscores,
    /// or digits.)  Their use is described in detail in the constructor and method comments.
    /// </summary>
    public class Formula
    {
        //Immutable list of tokens
        private readonly List<string> tokens;
        //Immutable HashSet to hold variables
        private readonly HashSet<string> variables;
        

        /// <summary>
        /// Creates a Formula from a string that consists of an infix expression written as
        /// described in the class comment.  If the expression is syntactically invalid,
        /// throws a FormulaFormatException with an explanatory Message.
        /// 
        /// The associated normalizer is the identity function, and the associated validator
        /// maps every string to true.  
        /// </summary>
        public Formula(String formula) :
            this(formula, s => s, s => true)
        {
        }

        /// <summary>
        /// Creates a Formula from a string that consists of an infix expression written as
        /// described in the class comment.  If the expression is syntactically incorrect,
        /// throws a FormulaFormatException with an explanatory Message.
        /// 
        /// The associated normalizer and validator are the second and third parameters,
        /// respectively.  
        /// 
        /// If the formula contains a variable v such that normalize(v) is not a legal variable, 
        /// throws a FormulaFormatException with an explanatory message. 
        /// 
        /// If the formula contains a variable v such that isValid(normalize(v)) is false,
        /// throws a FormulaFormatException with an explanatory message.
        /// 
        /// Suppose that N is a method that converts all the letters in a string to upper case, and
        /// that V is a method that returns true only if a string consists of one letter followed
        /// by one digit.  Then:
        /// 
        /// new Formula("x2+y3", N, V) should succeed
        /// new Formula("x+y3", N, V) should throw an exception, since V(N("x")) is false
        /// new Formula("2x+y3", N, V) should throw an exception, since "2x+y3" is syntactically incorrect.
        /// 
        /// Parsing Rules:
        /// Valid Tokens: parantheses, +, *, /, -, variables, decimal real numbers
        /// One token must always be present
        /// Number of closing parenthesis = Number of opening parentheses seen so far.
        /// Balanced Parntheses
        /// Expression first token = number, variable, opening parenthesis.
        /// Expression last token = number, variable, closing parenthesis.
        /// Parenthesis/Operator Following Rule - Any token that immediately follows an opening parenthesis or an operator must be either a number, a variable, or an opening parenthesis.
        /// Extra Following Rule - Any token that immediately follows a number, a variable, or a closing parenthesis must be either an operator or a closing parenthesis.
        /// </summary>
        public Formula(String formula, Func<string, string> normalize, Func<string, bool> isValid)
        {


            if (ReferenceEquals(formula, null))
            {
                throw new FormulaFormatException("Formula's can't be null");
            }

            tokens = new List<string>(GetTokens(formula));
            if (tokens.Count == 0 || formula.Equals(""))
            {
                throw new FormulaFormatException("There must be at atleast one token to be evaluated");
            }

            variables = new HashSet<string>();

            int openParantheses = 0;
            int closeParantheses = 0;
            double thisNumber = 0;

            string firstToken = tokens[0];
            string lastToken = tokens[tokens.Count-1];

            

            if (!firstToken.Equals("(") && !Double.TryParse(firstToken, out thisNumber) && !variableChecker(firstToken)){
                throw new FormulaFormatException("Expression's first token should be a number, variable, opening parenthesis.");
            }

            if (!(lastToken.Equals(")") || Double.TryParse(lastToken, out thisNumber) || variableChecker(lastToken)))
            {
                throw new FormulaFormatException("Expression's last token should be a number, variable, closing parenthesis.");

            }

            string previousToken = "";

            for(int i = 0; i < tokens.Count; i++)
            {
                string currentToken = tokens[i];
                if(!(currentToken.Equals("(") || currentToken.Equals(")") || currentToken.Equals("+") 
                    || currentToken.Equals("-") || currentToken.Equals("*") || currentToken.Equals("/")
                    || isValid(currentToken) || Double.TryParse(currentToken, out thisNumber)))
                {
                    throw new FormulaFormatException("Not a valid token");

                } else
                {
                    if (closeParantheses > openParantheses)
                    {
                        throw new FormulaFormatException("Number of opening parentheses should equal number of closing paranthesis.");
                    }

                    if ((previousToken.Equals("(") || previousToken.Equals("+") || previousToken.Equals("-") 
                        ||  previousToken.Equals("*") || previousToken.Equals("/"))
                        && !currentToken.Equals("(") && !Double.TryParse(currentToken, out thisNumber) 
                        && !variableChecker(currentToken))
                    {
                        throw new FormulaFormatException("Parenthesis/Operator Following Rule - " +
                            "Any token that immediately follows an opening parenthesis or an operator must be either a number, a variable, or an opening parenthesis.");

                    }
                    else if ((Double.TryParse(previousToken, out thisNumber) || variableChecker(previousToken) || previousToken.Equals(")"))
                            && (!currentToken.Equals("+") && !currentToken.Equals("-") && !currentToken.Equals("*") 
                                && !currentToken.Equals("/") && !currentToken.Equals(")"))
                        )
                    {
                        throw new FormulaFormatException("Extra Following Rule - Any token that immediately follows a number, " +
                            "a variable, or a closing parenthesis must be either an operator or a closing parenthesis.");
                    }

                    if (currentToken.Equals(")"))
                    {
                        closeParantheses++;
                    }
                    else if (currentToken.Equals("("))
                    {
                        openParantheses++;
                    }

                    previousToken = currentToken;
                }
            }
            if(openParantheses != closeParantheses)
            {
                throw new FormulaFormatException("Number of opening paranthesis needs to be equal to number of closing paranthesis.");
            }


            for(int i = 0; i < tokens.Count; i++)
            {
                string variable = tokens[i];
                if (variableChecker(variable))
                {
                    if (!(variableChecker(normalize(variable)))){
                        throw new FormulaFormatException("Variable cannot be normalized");
                    }

                    if (!((isValid(normalize(variable))))){
                        throw new FormulaFormatException("This variable is invalid.");
                    }
                    else
                    {
                        variable = normalize(variable);
                        variables.Add(variable);
                        tokens[i] = variable;
                    }
                }
            }

        }
        // tokens[i] = "5";


        /// <summary>
        /// Private helper method to help with performing the correct calculation based on which
        /// operator is associated with the two values in the expression.
        /// </summary>
        /// <param name="operators"></param>
        /// <param name="leftValue"></param>
        /// <param name="rightValue"></param>
        /// <returns></returns>
        private static double valueCalculation(string operators, double leftValue, double rightValue)
        {
            switch (operators)
            {
                case "+":
                    return leftValue + rightValue;

                case "-":
                    return leftValue - rightValue;

                case "*":
                    return leftValue * rightValue;

                default:
                    return leftValue / rightValue;

            }
        }

        /// <summary>
        /// This helper method was inspired from the Regex that was used in the FormulaEvaluator
        /// to check for the validity of a variable, which still remains a Letter followed by a Digit.
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        private static bool variableChecker(string token)
        {
            return Regex.IsMatch(token, @"[a-zA-Z_](?: [a-zA-Z_]|\d)*");
        }

        /// <summary>
        /// Evaluates this Formula, using the lookup delegate to determine the values of
        /// variables.  When a variable symbol v needs to be determined, it should be looked up
        /// via lookup(normalize(v)). (Here, normalize is the normalizer that was passed to 
        /// the constructor.)
        /// 
        /// For example, if L("x") is 2, L("X") is 4, and N is a method that converts all the letters 
        /// in a string to upper case:
        /// 
        /// new Formula("x+7", N, s => true).Evaluate(L) is 11
        /// new Formula("x+7").Evaluate(L) is 9
        /// 
        /// Given a variable symbol as its parameter, lookup returns the variable's value 
        /// (if it has one) or throws an ArgumentException (otherwise).
        /// 
        /// If no undefined variables or divisions by zero are encountered when evaluating 
        /// this Formula, the value is returned.  Otherwise, a FormulaError is returned.  
        /// The Reason property of the FormulaError should have a meaningful explanation.
        ///
        /// This method should never throw an exception.
        /// </summary>
        public object Evaluate(Func<string, double> lookup)
        {

            //split a string into tokens
            string[] substrings = tokens.ToArray();

            Stack<String> operators = new Stack<String>();
            Stack<double> values = new Stack<double>();
            double result = 0;

            foreach (string s in substrings)
            {
                //trim the given string to remove white spaces
                string token = s.Trim();

                //CONDITION: t is an double
                double numericValue;
                bool isDouble = Double.TryParse(token, out numericValue);
                if (isDouble == true)
                {
                    //If * or / is at the top of the operator stack, pop the value stack,
                    //pop the operator stack, and apply the popped operator to the popped number and t.
                    //Push the result onto the value stack. Otherwise, push t onto the value stack.
                    if (operators.onTopOfStack("*") || operators.onTopOfStack("/"))
                    {
                        if (values.Count >= 1)
                        {
                            double leftValue = values.Pop();
                            string oper = operators.Pop();
                            if (oper.Equals("/") && numericValue == 0)
                            {
                                //A division by zero occurs.
                                return new FormulaError("A division by 0 has occured");
                            }

                            result = valueCalculation(oper, leftValue, numericValue);
                            values.Push(result);

                        }
                    }
                    else
                    {
                        values.Push(numericValue);
                    }
                }

                //CONDITION: t is a variable
                else if (variableChecker(token))
                {
                    double variableLookup;

                    //normalize the token

                    //Proceed as above, using the looked-up value of t instead of t.
                    //EXCEPTIONS: If looking up t reveals it has no value(the delegate throws).
                    //try/catch
                    try
                    {
                        variableLookup = lookup(token);
                    }
                    catch
                    {
                        return new FormulaError("Invalid Variable");
                    }

                    //If * or / is at the top of the operator stack, pop the value stack,
                    //pop the operator stack, and apply the popped operator to the popped number
                    //and t. Push the result onto the value stack. Otherwise, push t onto the value
                    //stack.
                    if (operators.onTopOfStack("*") || operators.onTopOfStack("/"))
                    {
                        if (values.Count >= 1)
                        {
                            double rightValue = values.Pop();
                            string oper = operators.Pop();
                            if (oper.Equals("/") && variableLookup == 0)
                            {
                                return new FormulaError("A division by zero has occured");
                            }
                            result = valueCalculation(oper, rightValue, variableLookup);
                            values.Push(result);
                        }
                    }
                    else
                    {
                        values.Push(variableLookup);
                    }
                }

                //CONDITION: t is + or -	
                else if (token.Equals("+") || token.Equals("-"))
                {
                    //If + or - is at the top of the operator stack, pop the value stack twice and
                    //the operator stack once, then apply the popped operator to the popped numbers,
                    //then push the result onto the value stack. Push t onto the operator stack
                    if (operators.onTopOfStack("+") || operators.onTopOfStack("-"))
                    {
                        if (values.Count >= 2)
                        {
                            double rightValue = values.Pop();
                            double leftValue = values.Pop();
                            string oper = operators.Pop();
                            result = valueCalculation(oper, leftValue, rightValue);
                            values.Push(result);

                        }
                    }
                    operators.Push(token);
                }

                //CONDITION: t is * or /	
                //Push t onto the operator stack
                else if (token.Equals("*") || token.Equals("/"))
                {
                    operators.Push(token);
                }

                //CONDITION: t is a left parenthesis "("	
                //Push t onto the operator stack
                else if (token.Equals("("))
                {
                    operators.Push(token);
                }

                //CONDITION: t is a right parenthesis ")"	
                else if (token.Equals(")"))
                {
                    //If + or - is at the top of the operator stack, pop the value stack twice and
                    //the operator stack once. Apply the popped operator to the popped numbers.
                    //Push the result onto the value stack.
                    if (operators.onTopOfStack("+") || operators.onTopOfStack("-"))
                    {
                        if (values.Count >= 2)
                        {
                            double rightValue = values.Pop();
                            double leftValue = values.Pop();
                            string oper = operators.Pop();
                            result = valueCalculation(oper, leftValue, rightValue);
                            values.Push(result);

                        }
                    }
                    //Next, the top of the operator stack should be a '('.Pop it.
                    if (operators.onTopOfStack("("))
                    {
                        operators.Pop();
                    }

                    //Finally, if *or / is at the top of the operator stack, pop the value stack twice
                    //and the operator stack once. Apply the popped operator to the popped numbers.
                    //Push the result onto the value stack.
                    if (operators.onTopOfStack("*") || operators.onTopOfStack("/"))
                    {
                        if (values.Count >= 2)
                        {
                            double rightValue = values.Pop();
                            double leftValue = values.Pop();
                            string oper = operators.Pop();
                            if (oper.Equals("/") && rightValue == 0)
                            {
                                //A division by zero occurs
                                return new FormulaError("A division by zero occured");

                            }
                            else
                            {
                                result = valueCalculation(oper, leftValue, rightValue);
                                values.Push(result);
                            }
                        }

                    }
                }
            }
            //When the last token has been processed:

            //CONDITION:Operator stack is empty
            //Value stack should contain a single number.
            //Pop it and report as the value of the expression
            if (operators.Count == 0)
            {
                if (values.Count == 1)
                {
                    result = values.Pop();
                }
            }

            //CONDITION: Operator stack is not empty
            else if (operators.Count > 0)
            {
                //There should be exactly one operator on the operator stack,
                //and it should be either + or -.
                //There should be exactly two values on the value stack.Apply the operator
                //to the two values and report the result as the value of the expression.
                if (values.Count == 2)
                {
                    if (operators.Count == 1 && (operators.onTopOfStack("+") || operators.onTopOfStack("-")))
                    {
                        double rightValue = values.Pop();
                        double leftValue = values.Pop();
                        string oper = operators.Pop();
                        result = valueCalculation(oper, leftValue, rightValue);
                    }
                    
                }
            }

            return result;

        }

        /// <summary>
        /// Enumerates the normalized versions of all of the variables that occur in this 
        /// formula.  No normalization may appear more than once in the enumeration, even 
        /// if it appears more than once in this Formula.
        /// 
        /// For example, if N is a method that converts all the letters in a string to upper case:
        /// 
        /// new Formula("x+y*z", N, s => true).GetVariables() should enumerate "X", "Y", and "Z"
        /// new Formula("x+X*z", N, s => true).GetVariables() should enumerate "X" and "Z".
        /// new Formula("x+X*z").GetVariables() should enumerate "x", "X", and "z".
        /// </summary>
        public IEnumerable<String> GetVariables()
        {

            //storing variables in a HashSet to insure no duplicates.
            HashSet<String> result = new HashSet<String>(variables);
            return result;
        }

        /// <summary>
        /// Returns a string containing no spaces which, if passed to the Formula
        /// constructor, will produce a Formula f such that this.Equals(f).  All of the
        /// variables in the string should be normalized.
        /// 
        /// For example, if N is a method that converts all the letters in a string to upper case:
        /// 
        /// new Formula("x + y", N, s => true).ToString() should return "X+Y"
        /// new Formula("x + Y").ToString() should return "x+Y"
        /// </summary>
        public override string ToString() // 4 == 4.0
        {
            string stringFormula = "";

            for (int i = 0; i < tokens.Count; i++)
            {
                if (Double.TryParse(tokens[i], out double value))
                {
                    stringFormula += value.ToString(); // put code to turn value into a string.
                }
                else
                {
                    stringFormula += tokens[i];
                }
            }
            return stringFormula;
        }

        /// <summary>
        ///  <change> make object nullable </change>
        ///
        /// If obj is null or obj is not a Formula, returns false.  Otherwise, reports
        /// whether or not this Formula and obj are equal.
        /// 
        /// Two Formulae are considered equal if they consist of the same tokens in the
        /// same order.  To determine token equality, all tokens are compared as strings 
        /// except for numeric tokens and variable tokens.
        /// Numeric tokens are considered equal if they are equal after being "normalized" 
        /// by C#'s standard conversion from string to double, then back to string. This 
        /// eliminates any inconsistencies due to limited floating point precision.
        /// Variable tokens are considered equal if their normalized forms are equal, as 
        /// defined by the provided normalizer.
        /// 
        /// For example, if N is a method that converts all the letters in a string to upper case:
        ///  
        /// new Formula("x1+y2", N, s => true).Equals(new Formula("X1  +  Y2")) is true
        /// new Formula("x1+y2").Equals(new Formula("X1+Y2")) is false
        /// new Formula("x1+y2").Equals(new Formula("y2+x1")) is false
        /// new Formula("2.0 + x7").Equals(new Formula("2.000 + x7")) is true
        /// </summary>
        public override bool Equals(object? obj)
        {
            if (Equals(obj, null) || !(obj is Formula))
                return false;

            Formula formula = (Formula)obj;
            List<string> currentTokens = formula.tokens;

            for (int i = 0; i < tokens.Count; i++)
            {
                string thisFormula = this.tokens[i];
                string currentFormula = currentTokens[i];
                double thisNumber;
                double currentNumber;

                if ((Double.TryParse(thisFormula, out thisNumber)) && (Double.TryParse(currentFormula, out currentNumber)))
                {
                    if (thisNumber != currentNumber)
                        return false;
                }
                else
                {
                    if (!(thisFormula.Equals(currentFormula)))
                        return false;
                }
            }

            return true;
        }


        /// <summary>
        ///   <change> We are now using Non-Nullable objects.  Thus neither f1 nor f2 can be null!</change>
        /// Reports whether f1 == f2, using the notion of equality from the Equals method.
        /// This method's implementation was adopted from Dr. Daniel Kopta's implementaions
        /// of a Student's class with a == method.
        /// 
        /// </summary>
        public static bool operator ==(Formula f1, Formula f2)
        {
            return (!ReferenceEquals(f1, null) 
                && !ReferenceEquals(f2, null) 
                && f1.Equals(f2));  
        }

        /// <summary>
        ///   <change> We are now using Non-Nullable objects.  Thus neither f1 nor f2 can be null!</change>
        ///   <change> Note: != should almost always be not ==, if you get my meaning </change>
        ///   Reports whether f1 != f2, using the notion of equality from the Equals method.
        /// </summary>
        public static bool operator !=(Formula f1, Formula f2)
        {
            return !(f1 == f2);
        }

        /// <summary>
        /// Returns a hash code for this Formula.  If f1.Equals(f2), then it must be the
        /// case that f1.GetHashCode() == f2.GetHashCode().  Ideally, the probability that two 
        /// randomly-generated unequal Formulae have the same hash code should be extremely small.
        /// </summary>
        public override int GetHashCode()
        {
            return this.ToString().GetHashCode();
        }

        /// <summary>
        /// Given an expression, enumerates the tokens that compose it.  Tokens are left paren;
        /// right paren; one of the four operator symbols; a string consisting of a letter or underscore
        /// followed by zero or more letters, digits, or underscores; a double literal; and anything that doesn't
        /// match one of those patterns.  There are no empty tokens, and no token contains white space.
        /// </summary>
        private static IEnumerable<string> GetTokens(String formula)
        {
            // Patterns for individual tokens
            String lpPattern = @"\(";
            String rpPattern = @"\)";
            String opPattern = @"[\+\-*/]";
            String varPattern = @"[a-zA-Z_](?: [a-zA-Z_]|\d)*";
            String doublePattern = @"(?: \d+\.\d* | \d*\.\d+ | \d+ ) (?: [eE][\+-]?\d+)?";
            String spacePattern = @"\s+";

            // Overall pattern
            String pattern = String.Format("({0}) | ({1}) | ({2}) | ({3}) | ({4}) | ({5})",
                                            lpPattern, rpPattern, opPattern, varPattern, doublePattern, spacePattern);

            // Enumerate matching tokens that don't consist solely of white space.
            foreach (String s in Regex.Split(formula, pattern, RegexOptions.IgnorePatternWhitespace))
            {
                if (!Regex.IsMatch(s, @"^\s*$", RegexOptions.Singleline))
                {
                    yield return s;
                }
            }

        }
    }

    /// <summary>
    /// Used to report syntactic errors in the argument to the Formula constructor.
    /// </summary>
    public class FormulaFormatException : Exception
    {
        /// <summary>
        /// Constructs a FormulaFormatException containing the explanatory message.
        /// </summary>
        public FormulaFormatException(String message)
            : base(message)
        {
        }
    }

    /// <summary>
    /// Used as a possible return value of the Formula.Evaluate method.
    /// </summary>
    public struct FormulaError
    {
        /// <summary>
        /// Constructs a FormulaError containing the explanatory reason.
        /// </summary>
        /// <param name="reason"></param>
        public FormulaError(String reason)
            : this()
        {
            Reason = reason;
        }

        /// <summary>
        ///  The reason why this FormulaError was created.
        /// </summary>
        public string Reason { get; private set; }
    }
}


// <change>
//   If you are using Extension methods to deal with common stack operations (e.g., checking for
//   an empty stack before peeking) you will find that the Non-Nullable checking is "biting" you.
//
//   To fix this, you have to use a little special syntax like the following:
//
//       public static bool OnTop<T>(this Stack<T> stack, T element1, T element2) where T : notnull
//
//   Notice that the "where T : notnull" tells the compiler that the Stack can contain any object
//   as long as it doesn't allow nulls!
// </change>
