﻿Author:    Sasha Singh
Partner:   None
Date:      January 26th, 2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh
Repo:      https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:  b6babb2bd157fefcf563c30b0804d4e510fbc69c
Project:   Formula Evaluator
Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators + Assignment Specific Implementation:

# Consulted Peers:

# References:

# Time Spent:
	Test Cases- 100%