﻿```
Author:    Sasha Singh
Partner:   None
Date:      Feb-6-2022 to Feb-18-2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh
Repo:      https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:  d1f65648ef49e930ae5d9c0d23df5fd2214721c8
Project:   AbstractSpreadsheet
Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators + Assignment Specific Implementation:

AS5:

Notes from TA Tyler (Feb 18th):
- I was able to incorporate a validator into my existing variable checker to make sure that the variable entered is valid.
- We worked out two helper methods, one as a Lookup for the double value of a call, and one that serves the purpose of evaluating if the contents are a formula.
- He was able to  articulate my thoughts on what we need these helper methods for, where they belong in the code, and get the basic headers and return types 
  figured out. These changes are reflected in the code alonside the documentation.

Notes from TA Chris-
- Chris was able to help me better understand the state of the spreadsheet as it relates to setting the contents of the cell
depending on if it's a formula and the changed function. He helped me break up the string into a formula. 
-Chris helped me fix my formula class, it was missing a crictical part of the code where the Circular Exception wasn't being throw, 
He helped me keep track of what is inside of the cell and also store the old dependees. This is now reflected in the Catch block.
- I will also fix this in my FIX AS4-2 branch and master.

- He also helped me implement the Save method and make it easier to debug and gave me some pointers on how ti move forward with
a private helper method for Reading a file, the saved version and use all of that together in the constructor.
- He also took the time to explain to me the state ofthe spreadsheet in terms of the chnaged variable. When is it actually chnaged 
vs when is it saved and no longer changed.


Notes from TA Tanuja-
She was able to help me finish my Save method by helping me undersdtand what elements we need to end with and how the end of the file 
should look. She also helped me start my private readXML helper method and understand that it should then be called in the constructor and
the saved version method. The readXML method essentially reads the file but is also able to version it accordingly.

Changes/Implementaion in getSavedVersion and Reading the file was a recommendation from TA Narayani. 
She helped me see that you can just do this whenever a "spreadsheet" keyword appeared and the reading the contents of the file.
Design help on savedversion, Reading and Save were all done with her and she helped me walk through XML.


AS4:

I had lots of initial thoughts about how I want to start this assignment and what are some methods I can fill in right away
and what are some things that will take time to understand. 
I want to collect all my thoughts into one place and watched some lecture videos before I started working.
Here is a list of what I understood:

1) Instead of storing an infinite number of cells, we decide to store the empty ones in a Dictionary which contains a mapping to an actual cell.

2)The contents of a cell isn't the value stored inside of it, it's the actual formula you put in to create that value.

3)If the contents of a cell are empty, it's not null- it holds an empty string.

4)The cell class was one I struggled to understand, from what I understand a cell can either have a string, number, or formula- we don't have to worry about evaluating,
checking for the normalize or isValid delegate, we don't have a lookup. We don't have to worry about which setCellContent will be called depending on what the input is.
The cell class just has an overall Object that hold any of those three types and we don't have to worry about making three different constructors?

5)In PS4, a variable token is valid if they fit the token definition, that's it. No Validator Or Lookup delegate. The formula just exists. 
You don't need to call Double.TryParse, is a a parameter is stated as double- we don't have to think any further.

In Dr. Kopta's words regarding what a Cell class is:
"It doesn't need to track whether it's empty or not, since you can just delete it if it is.
It doesn't need to track its name, since that will be saved in a mapping somewhere else. From the instructions: "Use a suitable .NET library class to keep track of non-empty cells (i.e., there is a mapping from names to Cell objects)." If the map stores the names, then the cell object doesn't need to.
It doesn't need a value until PS5.
It doesn't need to be generic; you can just represent the cell contents using object."

6) GetNamesOfAllNonemptyCells operates in O(1),
Dictionary<TKey,TValue>.Keys Property automatically give you all the names in O(1) if using a dictionary to map names to cells.

7) Notes from TA Tyler-
My initial thoughts around the Cell class was to have one constructor that would match the three types to an object. He explained the drawbacks of this over three constructors
being- a user could techincally input the contents to be a Dependecy Graph and we have no way of insuring that it's only a string, double, or formula. 
I decided to take this advice but still make use of the Object super class.
-We also modified my variable checker helper method to account for a variable starting with a letter or underscore and then ending with the specified letters.
Wherever we were doing a check for if a variable is valid was changed to an OR instead of an ADD because we want to make sure both sides of the if statement
are checked. If a name isn't null then it should check for validity and vice versa.

8) Notes from TA Chris:
In order to make this assignment efficient and easier to implement- it's very important to look at what is already given to us.
He pointed out to me that in the SetCellContents methods- you can easily use your getCellsToReculculate to give the user exactly what they need. It relies
on the getdirectdepentdents method which is using the dependents method from the dependecny graph. 
He advised two options as to how a cell's content will become the number/formula/name and then you use that to update dependencies. I will be working on designing an UpdateDependencies
method.
After further thought, I decided to make my updateDependencies method more of a updating the contents of a cell, and then hadnling dependencies seperately within the 
SetCellContent mthods. Chris advised me to implement everything initially to make sure the update of contents is working correctly, and then go back and replace dependencies.
We also had some discussion about if I can replace with a List or a HashSet, either would work in this case.

9. Notes from TA Tanuja regarding testing, Cell nullable, contents of a cell, access modifiers, and typecast-
I was testing for SSC Doubles but was getting address of the cell, not the actual contents and that was an easy fix. I also changed everything in the cell class to be 
public so that all of its fields were accessible. TA Tanuja helped me write SSC code for double by type casting. 

10. I was a little confused on SSC for Formula's is any differnt than just the normal dependencies- the TA's were able to help me understand that if you replace a dependecy with
something that has nothing to do with another dependency- it doesn't matter. But if you add a dependency- you need to make sure it's not circular.
So we have to get the dependees and replace those correctly. TA Tanuja was able to help me implement this so that old dependencies were now replaces with the variables assoicated
with the specific formula.



# Consulted Peers:

Narayani Archunan TA for 1410

# References:
1. https://piazza.com/class/ky9bacgwi1q3sn?cid=472
2. https://utah.instructure.com/courses/717551/pages/week-5-lectures?module_item_id=16000616
3. https://utah.instructure.com/courses/717551/external_tools/90790
4. https://docs.microsoft.com/en-us/dotnet/api/system.collections.generic.dictionary-2.keys?view=net-5.
5. https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/out-parameter-modifier
6. https://www.delftstack.com/howto/csharp/how-to-convert-an-ienumerable-to-a-list-in-csharp/#:~:text=Use%20the%20ToList()%20Method%20to%20Convert,to%20a%20List%20in%20C&text=Copy%20Enumerable.,()%20has%20one%20parameter%20only.
7. https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/nullable-value-types
9. Circular Errors in Excel- https://exceljet.net/formula/how-to-fix-a-circular-reference-error#:~:text=The%20circular%20reference%20error%20message&text=%22There%20are%20one%20or%20more,the%20formulas%20to%20different%20cells.%22


1. https://utah.instructure.com/courses/717551/external_tools/90790, https://utah.instructure.com/courses/717551/external_tools/90790, https://utah.instructure.com/courses/717551/external_tools/90790
2. https://docs.microsoft.com/en-us/dotnet/api/system.string.substring?view=net-6.0
3. https://docs.microsoft.com/en-us/dotnet/api/system.xml.xmlwriter?view=net-6.0
4. https://docs.microsoft.com/en-us/dotnet/api/system.xml.xmlwritersettings?view=net-6.0
5. https://docs.microsoft.com/en-us/dotnet/api/system.xml.xmldocument.save?view=net-6.0
6. https://github.com/Utah-School-of-Computing-de-St-Germain/ForStudents/blob/main/Examples/XMLDemo/Nations/Nation.cs
7. https://docs.microsoft.com/en-us/dotnet/api/system.xml.xmlreader.readtofollowing?view=net-6.0

#Examples of Good Software Practice (GSP):

1. Recycling old code- I was able to resue codce from Formula and Dependency Graph and the same Regex check for variables.
2. Helper Methods- I had a helped method to update the contents of the cell
3. Clearly labeled variables, methods, commented sections of code- all variables and testcases and methods are clearly labeled and header comments wlk 
through the exact procedure of the program. Lot's of examples that can be used to visualize the state of the spreadsheet at all times.


# Time Spent:

    #AS4:
    Overall time estimate - 10 hours 

    Feb 8 & 9- Setup + Fixing old code  - 2 hours
    Feb 10th - 4 hours
    Feb 11th- 6 hours

    Total Time: 12 hours

    #AS5:

    Overall time estimate - 15 hours 

    Total Time: 15 hours


