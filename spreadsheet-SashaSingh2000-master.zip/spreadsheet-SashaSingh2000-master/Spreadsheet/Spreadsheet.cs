﻿using SpreadsheetUtilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;

namespace SS
{
    /// <summary>
    /// Author:    Sasha Singh
    /// Partner:   None
    /// Date:      18th-Feb-2022
    /// Course:    CS 3500, University of Utah, School of Computing 
    /// Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework. 
    /// 
    /// I, Sasha Singh, certify that I wrote this code from scratch and did not copy it in part or whole from  
    /// another source.  All references used in the completion of the assignment are cited in my README file. 
    /// 
    /// File Contents: AbstractSpreadsheet.cs which is a fully abstract class. Spreadsheet.cs that inherits from it and
    /// contains the overall program for what a Spreadsheet is made of.
    /// SpreadsheetTests.cs which will contain a comprehensive list of tests
    /// to make sure that cells are stored correctly and in the right place, empty vs non empty cells, if circular dependecies are prevented, and the overall function 
    /// of the program.
    /// 
    /// <para>
    ///     An AbstractSpreadsheet object represents the state of a simple spreadsheet.  A 
    ///     spreadsheet consists of an infinite number of named cells.
    /// </para>
    /// <para>
    ///     A string is a valid cell name if and only if:
    /// </para>
    /// <list type="number">
    ///      <item> it starts with one or more letters</item>
    ///      <item> it ends with one or more numbers (digits)</item>
    /// </list>   
    /// 
    /// <para>
    ///     For example, "A15", "a15", "XY032", and "BC7" are cell names so long as they
    ///     satisfy IsValid.  On the other hand, "Z", "X_", and "hello" are not cell names,
    ///     regardless of IsValid.
    /// </para>
    ///
    /// <para>
    ///     Any valid incoming cell name, whether passed as a parameter or embedded in a formula,
    ///     must be normalized with the Normalize method before it is used by or saved in 
    ///     this spreadsheet.  For example, if Normalize is s => s.ToUpper(), then
    ///     the Formula "x3+a5" should be converted to "X3+A5" before use.
    /// </para>
    /// 
    /// <para>
    ///     A spreadsheet contains a cell corresponding to every possible cell name.  (This
    ///     means that a spreadsheet contains an infinite number of cells.)  In addition to 
    ///     a name, each cell has a contents and a value.  The distinction is important.
    /// </para>
    /// 
    /// <para>
    ///     The contents of a cell can be (1) a string, (2) a double, or (3) a Formula.  If the
    ///     contents is an empty string, we say that the cell is empty.  (By analogy, the contents
    ///     of a cell in Excel is what is displayed on the editing line when the cell is selected.)
    /// </para>
    /// 
    /// <para>
    ///     In a new spreadsheet, the contents of every cell is the empty string. Note: 
    ///     this is by definition (it is IMPLIED, not stored).
    /// </para>
    /// 
    /// <para>
    ///     The value of a cell can be (1) a string, (2) a double, or (3) a FormulaError.  
    ///     (By analogy, the value of an Excel cell is what is displayed in that cell's position
    ///     in the grid.)
    /// </para>
    /// 
    /// <list type="number">
    ///   <item>If a cell's contents is a string, its value is that string.</item>
    /// 
    ///   <item>If a cell's contents is a double, its value is that double.</item>
    /// 
    ///   <item>
    ///      If a cell's contents is a Formula, its value is either a double or a FormulaError,
    ///      as reported by the Evaluate method of the Formula class.  The value of a Formula,
    ///      of course, can depend on the values of variables.  The value of a variable is the 
    ///      value of the spreadsheet cell it names (if that cell's value is a double) or 
    ///      is undefined (otherwise).
    ///   </item>
    /// 
    /// </list>
    /// 
    /// <para>
    ///     Spreadsheets are never allowed to contain a combination of Formulas that establish
    ///     a circular dependency.  A circular dependency exists when a cell depends on itself.
    ///     For example, suppose that A1 contains B1*2, B1 contains C1*2, and C1 contains A1*2.
    ///     A1 depends on B1, which depends on C1, which depends on A1.  That's a circular
    ///     dependency.
    /// </para>
    /// </summary>
    public class Spreadsheet : AbstractSpreadsheet
    {
        // keeps track of non-empty cells (i.e., there is a mapping from names to Cell objects).
        private Dictionary<String, Cell> nonEmptyCells;
        //keeps track of the relationships among spreadsheet cells.
        private DependencyGraph relationshipsGraph;


        /// <summary>
        ///Zero argument constructor creates an empty spreadsheet
        ///that imposes no extra validity conditions, normalizes every cell name to 
        ///itself, and use the name "default" as the version.      
        /// </summary>
        public Spreadsheet() : this(s => true, s => s, "default")
        {

        }

        /// <summary>
        /// Three argument constructor creates an empty spreadsheet. 
        /// However, it should allow the user to provide a validity delegate 
        /// (first parameter), a normalization delegate (second parameter), 
        /// and a version (third parameter).
        /// </summary>
        /// <param name="isValid"></param>
        /// <param name="normalize"></param>
        /// <param name="version"></param>
        public Spreadsheet(Func<string, bool> isValid, Func<string, string> normalize, string version) : base(isValid, normalize, version)
        {
            nonEmptyCells = new Dictionary<String, Cell>();
            relationshipsGraph = new DependencyGraph();
            Changed = false;
        }

        /// <summary>
        ///  Four-argument constructor allows the user to provide a string representing
        ///  a path to a file (first parameter), a validity delegate (second parameter), 
        ///  a normalization delegate (third parameter), and a version (fourth parameter). 
        ///  It should read a saved spreadsheet from the file (see the Save method) and use 
        ///  it to construct a new spreadsheet. The new spreadsheet should use the provided 
        ///  validity delegate, normalization delegate, and version. 
        /// </summary>
        /// <param name="filepath"></param>
        /// <param name="isValid"></param>
        /// <param name="normalize"></param>
        /// <param name="version"></param>
        public Spreadsheet(string filepath, Func<string, bool> isValid, Func<string, string> normalize, string version)
          : this(isValid, normalize, version)
        {

            //call getSavedVersion and read the file

            if (!GetSavedVersion(filepath).Equals(version))
            {
                throw new SpreadsheetReadWriteException("The version of the saved spreadsheet does not match the version parameter");
            }
            ReadXML(filepath, normalize);
            Changed = false;

        }

        /// <summary>
        /// True if this spreadsheet has been modified since it was created or saved                  
        /// (whichever happened most recently); false otherwise.
        /// </summary>
        public override bool Changed { get; protected set; }


        /// <summary>
        /// This helper method was inspired from the Regex that was used in the FormulaEvaluator
        /// to check for the validity of a variable. A string is a valid cell name if and only if:
        ///   (1) its first character is an underscore or a letter
        ///   (2) its remaining characters (if any) are underscores and/or letters and/or digits
        /// Note that this is the same as the definition of valid variable from the PS3 Formula class.
        /// 
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        private bool variableChecker(string token)
        {
            bool isVar = false;
            //Recheck variable checker
            if (Regex.IsMatch(token, @"^[a-zA-Z_](?: [a-zA-Z_]|\d)*$"))
            {
                isVar = true;
            }
            if (IsValid(token))
            {
                isVar = true;
            }
            else
            {
                isVar = false;
            }
            return isVar;
        }

        /// <summary>
        ///   Returns the contents (as opposed to the value) of the named cell.
        /// </summary>
        /// 
        /// <exception cref="InvalidNameException"> 
        ///   Thrown if the name is invalid: blank/empty/""
        /// </exception>
        /// 
        /// <param name="name">The name of the spreadsheet cell to query</param>
        /// 
        /// <returns>
        ///   The return value should be either a string, a double, or a Formula.
        ///   See the class header summary 
        /// </returns>
        public override object GetCellContents(string name)
        {
            if (name == null || !variableChecker(name))
            {
                throw new InvalidNameException();
            }
            name = Normalize(name);
            Cell? namedCellContent;
            if (nonEmptyCells.TryGetValue(name, out namedCellContent))
            {
                //return contents of the named cell
                return namedCellContent.contents;
            }
            else
            {
                return "";
            }
        }


        /// <summary>
        ///   Returns the names of all non-empty cells.
        /// </summary>
        /// 
        /// <returns>
        ///     Returns an Enumerable that can be used to enumerate
        ///     the names of all the non-empty cells in the spreadsheet.  If 
        ///     all cells are empty then an IEnumerable with zero values will be returned.
        /// </returns>
        public override IEnumerable<string> GetNamesOfAllNonemptyCells()
        {
            return nonEmptyCells.Keys;
        }

        /// <summary>
        /// This helper method aids in updating dependencies based on three criterias:
        /// Either there are Old Dependencies, but no New ones- and you are replacing it wil soemthing that ddoesn't reference any cells.
        /// Or there are old and new dependencies, Or there are new Dependencies but no old ones.
        /// The helper method itself only updates the contents of a cell, doesn't replace dependencies.
        /// 
        /// Examples are listed below:
        /// A1: 5, SCC(B1, 2*A1)
        /// A1: 5, B1: "=2*A1", SCC(B1, "=2*C1")
        /// A1: 5, B1: "=2*C1", SCC(B1, "hello")
        /// </summary>
        /// <param name="cellToUpdate"></param>
        /// <param name="nameOfCell"></param>
        private void updateSpreadsheetContent(Cell cellToUpdate, string nameOfCell)
        {
            if (nonEmptyCells.ContainsKey(nameOfCell))
            {
                //if a key exists, replace it with the new Cell
                nonEmptyCells[nameOfCell] = cellToUpdate;
            }
            else
            {
                //Else add it to the dictionary
                nonEmptyCells.Add(nameOfCell, cellToUpdate);
            }
        }

        /// <summary>
        ///  Set the contents of the named cell to the given number.  
        /// </summary>
        /// 
        /// <requires> 
        ///   The name parameter must be valid: non-empty/not ""
        /// </requires>
        /// 
        /// <exception cref="InvalidNameException"> 
        ///   If the name is invalid, throw an InvalidNameException
        /// </exception>
        /// 
        /// <param name="name"> The name of the cell </param>
        /// <param name="number"> The new contents/value </param>
        /// 
        /// <returns>
        ///   <para>
        ///       This method returns a LIST consisting of the passed in name followed by the names of all 
        ///       other cells whose value depends, directly or indirectly, on the named cell.
        ///   </para>
        ///
        ///   <para>
        ///       The order must correspond to a valid dependency ordering for recomputing
        ///       all of the cells, i.e., if you re-evaluate each cell in the order of the list,
        ///       the overall spreadsheet will be consistently updated.
        ///   </para>
        ///
        ///   <para>
        ///     For example, if name is A1, B1 contains A1*2, and C1 contains B1+A1, the
        ///     set {A1, B1, C1} is returned, i.e., A1 was changed, so then A1 must be 
        ///     evaluated, followed by B1 re-evaluated, followed by C1 re-evaluated.
        ///   </para>
        /// </returns>
        protected override IList<string> SetCellContents(string name, double number)
        {
            if (name == null || !variableChecker(name))
            {
                throw new InvalidNameException();
            }

            //contents get set to number
            Cell doubleCell = new Cell(number);
            updateSpreadsheetContent(doubleCell, name);

            //Because changing a dependency to now something that doesn't depend on anything is no dependencies.
            relationshipsGraph.ReplaceDependees(name, new HashSet<string>());

            return GetCellsToRecalculate(name).ToList();
        }

        /// <summary>
        /// The contents of the named cell becomes the text.  
        /// </summary>
        /// 
        /// <requires> 
        ///   The name parameter must be valid/non-empty ""
        /// </requires>
        /// 
        /// <exception cref="InvalidNameException"> 
        ///   If the name is invalid, throw an InvalidNameException
        /// </exception>       
        /// 
        /// <param name="name"> The name of the cell </param>
        /// <param name="text"> The new content/value of the cell</param>
        /// 
        /// <returns>
        ///   <para>
        ///       This method returns a LIST consisting of the passed in name followed by the names of all 
        ///       other cells whose value depends, directly or indirectly, on the named cell.
        ///   </para>
        ///
        ///   <para>
        ///       The order must correspond to a valid dependency ordering for recomputing
        ///       all of the cells, i.e., if you re-evaluate each cell in the order of the list,
        ///       the overall spreadsheet will be consistently updated.
        ///   </para>
        ///
        ///   <para>
        ///     For example, if name is A1, B1 contains A1*2, and C1 contains B1+A1, the
        ///     set {A1, B1, C1} is returned, i.e., A1 was changed, so then A1 must be 
        ///     evaluated, followed by B1 re-evaluated, followed by C1 re-evaluated.
        ///   </para>
        /// </returns>
        protected override IList<string> SetCellContents(string name, string text)
        {
            if (text == null)
            {
                throw new ArgumentNullException();
            }
            if(text == "")
            {
                nonEmptyCells.Remove(name);
            }
            if (name == null || !variableChecker(name))
            {
                throw new InvalidNameException();
            }
            else
            {
                Cell textContent = new Cell(text);
                updateSpreadsheetContent(textContent, name);
            }

            //Because changing a dependency to now something that doesn't depend on anything is no dependencies.
            relationshipsGraph.ReplaceDependees(name, new HashSet<string>());

            return GetCellsToRecalculate(name).ToList();
        }

        /// <summary>
        /// Set the contents of the named cell to the formula.  
        /// </summary>
        /// 
        /// <requires> 
        ///   The name parameter must be valid/non empty
        /// </requires>
        /// 
        /// <exception cref="InvalidNameException"> 
        ///   If the name is invalid, throw an InvalidNameException
        /// </exception>
        /// 
        /// <exception cref="CircularException"> 
        ///   If changing the contents of the named cell to be the formula would 
        ///   cause a circular dependency, throw a CircularException.  
        ///   (NOTE: No change is made to the spreadsheet.)
        /// </exception>
        /// 
        /// <param name="name"> The cell name</param>
        /// <param name="formula"> The content of the cell</param>
        /// 
        /// <returns>
        ///   <para>
        ///       This method returns a LIST consisting of the passed in name followed by the names of all 
        ///       other cells whose value depends, directly or indirectly, on the named cell.
        ///   </para>
        ///
        ///   <para>
        ///       The order must correspond to a valid dependency ordering for recomputing
        ///       all of the cells, i.e., if you re-evaluate each cell in the order of the list,
        ///       the overall spreadsheet will be consistently updated.
        ///   </para>
        ///
        ///   <para>
        ///     For example, if name is A1, B1 contains A1*2, and C1 contains B1+A1, the
        ///     set {A1, B1, C1} is returned, i.e., A1 was changed, so then A1 must be 
        ///     evaluated, followed by B1 re-evaluated, followed by C1 re-evaluated.
        ///   </para>
        /// </returns>
        protected override IList<string> SetCellContents(string name, Formula formula)
        {

           /* Cell cell = nonEmptyCells[name];
            IEnumerable<string> oldDependees = relationshipsGraph.GetDependents(name);  */

            if(formula == null)
            {
                throw new ArgumentNullException();
            }
            if (name == null || !variableChecker(name))
            {
                throw new InvalidNameException();
            }
            try
            {
                Cell formulaCell = new Cell(formula, Lookup);
                updateSpreadsheetContent(formulaCell, name);
                //The dependees are now replaced with a list of variables attached to that formula.
                relationshipsGraph.ReplaceDependees(name, formula.GetVariables());
                return GetCellsToRecalculate(name).ToList();
            }
            catch (CircularException ex)
            {
                //nonEmptyCells[name] = cell;
                //relationshipsGraph.ReplaceDependees(name, oldDependees);
                throw new CircularException();
            }

        }

        /// <summary>
        /// Returns an enumeration, without duplicates, of the names of all cells whose
        /// values depend directly on the value of the named cell. 
        /// </summary>
        /// 
        /// <exception cref="InvalidNameException"> 
        ///   If the name is invalid, throw an InvalidNameException
        /// </exception>
        /// 
        /// <param name="name"></param>
        /// <returns>
        ///   Returns an enumeration, without duplicates, of the names of all cells that contain
        ///   formulas containing name.
        /// 
        ///   <para>For example, suppose that: </para>
        ///   <list type="bullet">
        ///      <item>A1 contains 3</item>
        ///      <item>B1 contains the formula A1 * A1</item>
        ///      <item>C1 contains the formula B1 + A1</item>
        ///      <item>D1 contains the formula B1 - C1</item>
        ///   </list>
        /// 
        ///   <para>The direct dependents of A1 are B1 and C1</para>
        /// 
        /// </returns>
        protected override IEnumerable<string> GetDirectDependents(string name)
        {
            return relationshipsGraph.GetDependents(name);
        }

        /// <summary>
        ///   <para>Sets the contents of the named cell to the appropriate value. </para>
        ///   <para>
        ///       First, if the content parses as a double, the contents of the named
        ///       cell becomes that double.
        ///   </para>
        ///
        ///   <para>
        ///       Otherwise, if content begins with the character '=', an attempt is made
        ///       to parse the remainder of content into a Formula.  
        ///       There are then three possible outcomes:
        ///   </para>
        ///
        ///   <list type="number">
        ///       <item>
        ///           If the remainder of content cannot be parsed into a Formula, a 
        ///           SpreadsheetUtilities.FormulaFormatException is thrown.
        ///       </item>
        /// 
        ///       <item>
        ///           If changing the contents of the named cell to be f
        ///           would cause a circular dependency, a CircularException is thrown,
        ///           and no change is made to the spreadsheet.
        ///       </item>
        ///
        ///       <item>
        ///           Otherwise, the contents of the named cell becomes f.
        ///       </item>
        ///   </list>
        ///
        ///   <para>
        ///       Finally, if the content is a string that is not a double and does not
        ///       begin with an "=" (equal sign), save the content as a string.
        ///   </para>
        /// </summary>
        ///
        /// <exception cref="InvalidNameException"> 
        ///   If the name parameter is null or invalid, throw an InvalidNameException
        /// </exception>
        /// 
        /// <exception cref="SpreadsheetUtilities.FormulaFormatException"> 
        ///   If the content is "=XYZ" where XYZ is an invalid formula, throw a FormulaFormatException.
        /// </exception>
        /// 
        /// <exception cref="CircularException"> 
        ///   If changing the contents of the named cell to be the formula would 
        ///   cause a circular dependency, throw a CircularException.  
        ///   (NOTE: No change is made to the spreadsheet.)
        /// </exception>
        /// 
        /// <param name="name"> The cell name that is being changed</param>
        /// <param name="content"> The new content of the cell</param>
        /// 
        /// <returns>
        ///       <para>
        ///           This method returns a list consisting of the passed in cell name,
        ///           followed by the names of all other cells whose value depends, directly
        ///           or indirectly, on the named cell. The order of the list MUST BE any
        ///           order such that if cells are re-evaluated in that order, their dependencies 
        ///           are satisfied by the time they are evaluated.
        ///       </para>
        ///
        ///       <para>
        ///           For example, if name is A1, B1 contains A1*2, and C1 contains B1+A1, the
        ///           list {A1, B1, C1} is returned.  If the cells are then evaluate din the order:
        ///           A1, then B1, then C1, the integrity of the Spreadsheet is maintained.
        ///       </para>
        /// </returns>
        public override IList<string> SetContentsOfCell(string name, string content)
        {
            // Store in a Variable IList

            name = Normalize(name);

            IList<string> cellsToRecalculate = new List<string>();

            if (name == null || !variableChecker(name))
            {
                throw new InvalidNameException();
            }

            // if the content parses as a double, the contents of the named cell becomes that double.
            if (Double.TryParse(content, out double Dvalue))
            {
                cellsToRecalculate = SetCellContents(name, Dvalue);
                Changed = true;
            }
            // Otherwise, if content begins with the character '=', an attempt is made
            //to parse the remainder of content into a Formula. 
            else if (content.StartsWith("="))
            {
                    //take off equal sign- you can use substring 
                    string FormulaToBeMade = content.Substring(1);
                    //Formula can be made from a string 
                    Formula formula = new Formula(FormulaToBeMade, Normalize, variableChecker);
                    //setCellContent
                    cellsToRecalculate = SetCellContents(name, formula);
                    Changed = true;
                
            }
                else
                {
                    //Finally, if the content is a string that is not a double and does not
                    //begin with an "=" (equal sign), save the content as a string.
                   cellsToRecalculate = SetCellContents(name, content);
                    Changed = true;
                }

                // The order of the list MUST BE any
                //order such that if cells are re-evaluated in that order, their dependencies 
                //are satisfied by the time they are evaluated.
            foreach (string s in cellsToRecalculate)
                {
                    if (nonEmptyCells.TryGetValue(s, out Cell? cellValue))
                    {
                       cellValue.Evaluate(Lookup);
                    }
                }
                                              
            Changed = true;
            return cellsToRecalculate;
        }
        

        /// <summary>
        ///   Look up the version information in the given file. If there are any problems opening, reading, 
        ///   or closing the file, the method should throw a SpreadsheetReadWriteException with an explanatory message.
        /// </summary>
        /// 
        /// <remarks>
        ///   In an ideal world, this method would be marked static as it does not rely on an existing SpreadSheet
        ///   object to work; indeed it should simply open a file, lookup the version, and return it.  Because
        ///   C# does not support this syntax, we abused the system and simply create a "regular" method to
        ///   be implemented by the base class.
        /// </remarks>
        /// 
        /// <exception cref="SpreadsheetReadWriteException"> 
        ///   Thrown if any problem occurs while reading the file or looking up the version information.
        /// </exception>
        /// 
        /// <param name="filename"> The name of the file (including path, if necessary)</param>
        /// 
        /// //Written with the help of Narayani Archunan
        /// <returns>Returns the version information of the spreadsheet saved in the named file.</returns>
        public override string GetSavedVersion(string filename)
        {
            try
            {
                using (XmlReader reader = XmlReader.Create(filename))
                {                    
                        if (reader.ReadToFollowing("spreadsheet"))
                        {
                            return reader["version"];

                        }
                        else
                        {
                            throw new SpreadsheetReadWriteException("Problem occured while reading the file or looking up the version information");
                        }
                    }
                
            }
            catch (Exception ex)
            {
                throw new SpreadsheetReadWriteException("Reading the file or looking up version failed.");
            }
            
        }

        /// <summary>
        /// This private helper method aids in Reading a XML file and finding the keywords that are 
        /// essential here. Inspired from Dr.de St Germains' DEMO and help from
        /// TA Narayani.
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="normalize"></param>
        /// <exception cref="SpreadsheetReadWriteException"></exception>
        private void ReadXML(string filename, Func<string, string> normalize)
        {
            string name = "";
            string content = "";

            try
            {
                using (XmlReader reader = XmlReader.Create(filename))
                {
                    while (reader.Read())
                    {
                        if (reader.IsStartElement())
                        {
                            switch (reader.Name)
                            {
                                case "spreadsheet":
                                    break;

                                case "cell":
                                    break;

                                case "name":
                                    reader.MoveToContent();
                                    name = reader.ReadElementContentAsString();
                                    name = normalize(name);
                                    break;

                                case "contents":
                                    reader.MoveToContent();
                                    content = reader.ReadElementContentAsString();
                                    SetContentsOfCell(name, content);
                                    break;
                            }

                        }
                    }
                }

            }
            catch (Exception e)
            {
                throw new SpreadsheetReadWriteException("There was a problem reading the file.");

            }
        }



    /// <summary>
    /// Writes the contents of this spreadsheet to the named file using an XML format.
    /// The XML elements should be structured as follows:
    /// 
    /// <spreadsheet version="version information goes here">
    /// 
    /// <cell>
    /// <name>cell name goes here</name>
    /// <contents>cell contents goes here</contents>    
    /// </cell>
    /// 
    /// </spreadsheet>
    /// 
    /// There should be one cell element for each non-empty cell in the spreadsheet.  
    /// If the cell contains a string, it should be written as the contents.  
    /// If the cell contains a double d, d.ToString() should be written as the contents.  
    /// If the cell contains a Formula f, f.ToString() with "=" prepended should be written as the contents.
    /// 
    /// If there are any problems opening, writing, or closing the file, the method should throw a
    /// SpreadsheetReadWriteException with an explanatory message.
    /// </summary>
    public override void Save(string filename)
        {
            try
            {
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.IndentChars = " ";
                using (XmlWriter writer = XmlWriter.Create(filename, settings))
                {
                    writer.WriteStartDocument();
                    writer.WriteStartElement("spreadsheet");
                    //spreadsheet version
                    writer.WriteAttributeString("version", Version);

                    foreach (string cellName in nonEmptyCells.Keys)
                    {
                        writer.WriteStartElement("cell");
                        writer.WriteStartElement("name", cellName);
                        string writtenAs;


                        if (nonEmptyCells[cellName].contents is double)
                        {
                            //If the cell contains a double d, d.ToString() should be written as the contents.  
                            writtenAs = nonEmptyCells[cellName].contents.ToString();
                        }
                        else if (nonEmptyCells[cellName].contents is Formula)
                        {
                            //If the cell contains a Formula f, f.ToString() with "=" prepended should be written as the content
                            writtenAs = "=" + nonEmptyCells[cellName].contents.ToString();
                        }
                        else
                        {
                            //If the cell contains a string, it should be written as the contents.  
                            writtenAs = (string)nonEmptyCells[cellName].contents;
                        }

                        writer.WriteElementString("contents", writtenAs);
                        writer.WriteEndElement();

                    }
                    writer.WriteEndDocument();

                }
            }
            catch(Exception ex)
            {
                throw new SpreadsheetReadWriteException("There was a problem opening, writing, or closing the file");
            }

            Changed = false;
        }

        /// <summary>
        /// If name is invalid, throws an InvalidNameException.
        /// </summary>
        ///
        /// <exception cref="InvalidNameException"> 
        ///   If the name is invalid, throw an InvalidNameException
        /// </exception>
        /// 
        /// <param name="name"> The name of the cell that we want the value of (will be normalized)</param>
        /// 
        /// <returns>
        ///   Returns the value (as opposed to the contents) of the named cell.  The return
        ///   value should be either a string, a double, or a SpreadsheetUtilities.FormulaError.
        /// </returns>
        public override object GetCellValue(string name)
        {
            if (!variableChecker(name))
            {
                throw new InvalidNameException();
            }

            Cell? nameValue;
            name = Normalize(name);
            Object result = "";
            bool isGetValue = nonEmptyCells.TryGetValue(name, out nameValue);
            if (isGetValue)
            {
                result = nameValue.values;
            }
            return result;
        }

        /// <summary>
        /// This helper method was created to see 
        /// If the nonEmptyCell dictionary contains that name, see if it's a double - cast cell value to a double and return it.
        /// If not, throw an Arguement Ex
        /// It makes use of nonEmptyCells.TryGetValue(name, out Cell? cellObj)
        /// This method was written with TA Tyler. 
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private double Lookup(string name)
        { 
            if(nonEmptyCells.TryGetValue(name, out Cell? cellObj))
            {
                if(cellObj.values is Double)
                {
                    return (double)cellObj.values;
                }
                else
                {
                    throw new ArgumentException();
                }
            }
            else
            {
                throw new ArgumentException();
            }

        }

        /// <summary>
        /// A private cell class insures:
        /// The contents of a cell can be (1) a string, (2) a double, or (3) a Formula.  If the
        /// contents is an empty string, we say that the cell is empty.  (By analogy, the contents
        /// of a cell in Excel is what is displayed on the editing line when the cell is selected.)
        /// 
        /// In a new spreadsheet, the contents of every cell is the empty string.
        ///  
        /// The value of a cell can be (1) a string, (2) a double, or (3) a FormulaError.  
        /// (By analogy, the value of an Excel cell is what is displayed in that cell's position
        /// in the grid.)
        /// 
        /// If a cell's contents is a string, its value is that string.
        /// 
        /// If a cell's contents is a double, its value is that double.
        /// 
        /// If a cell's contents is a Formula, its value is either a double or a FormulaError,
        /// as reported by the Evaluate method of the Formula class.  The value of a Formula,
        /// of course, can depend on the values of variables.  The value of a variable is the 
        /// value of the spreadsheet cell it names (if that cell's value is a double) or 
        /// is undefined (otherwise).
        /// 
        /// For the purpose of this assignment, we are concerned about the contents and the actual value stored in that cell.
        /// </summary>
        public class Cell
        {
            public Object contents;
            public Object values;

            public Cell(double content)
            {
                contents = content;
                values = content;
            }
            public Cell(string content)
            {
                contents = content;
                values = content;

            }
            public Cell(Formula content, Func<string, double> lookup)
            {
                contents = content;
                if (content is Formula)
                {
                    values = content.Evaluate(lookup);
                }
                values = content;

            }

            /// <summary>
            /// The purpose of this helper method is to check to see if the contents of a Cell is a Formula and get the Value 
            /// by calling the Evaluate using the lookup.
            /// If contents is a Formula, - value = formula.Evaluate(lookup)
            /// Otherwise the value is the contents if it's a string or double. 
            /// This method was written with TA Tyler.
            /// </summary>
            /// <param name="lookup"></param>
            public void Evaluate(Func<string, double> lookup)
            { 
               if(contents is Formula)
                {
                    Formula formula = (Formula)contents;
                    values = formula.Evaluate(lookup);
                }
                else
                {
                    values = contents;
                }

            }

        }

    }
}