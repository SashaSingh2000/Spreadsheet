﻿namespace Extensions
{
    /// <summary>
    /// Author: Sasha Singh
    /// Partners: None
    /// Date: Feb 3rd 2022
    /// </summary>
    public static class Extensions
    {
        /// <summary>
        /// This method uses a simple check in order for the Peek method to not throw an 
        /// exception. This methods makes sure that there is something to look at the top of the 
        /// stack and it can be looked at without removing it.
        /// </summary>
        /// <param name="s"></param>
        /// <param name="toCheck"></param>
        /// <returns></returns>
        public static bool onTopOfStack(this Stack<string> s, string toCheck)
        {
            return s.Count > 0 && s.Peek() == toCheck;
        }

    }
}