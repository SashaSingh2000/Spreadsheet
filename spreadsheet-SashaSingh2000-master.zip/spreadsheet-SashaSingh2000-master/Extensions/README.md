﻿```
Author:    Sasha Singh
Partner:   None
Date:      Feburary 3rd 2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh
Repo:      https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:  70a3000fda110ffc1680f9c4c3ec9ff87c40deb4
Project:   Formula Evaluator + Formula
Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators + Assignment Specific Implementation:

1) Having taken this class in the past, I was able to recall a common code repition which was 
related to looking at the top of a stack to see what operator was at the top.
In order to perform a peek information, you have to make sure that there is something at the top
of the stack and that it isn't empty. Now, to avoid repeating this code each time we do a peek
operation- I chose to make a Stack Extension method. From my understand an extension method is 
basically syntactic sugar that "adds" an extra method to that specific class without actually 
modifying it. This method is called "onTopOfStack" and is within the same namespace. 
This method/code design was adopted from Dr. Daniel Kopta from CS 3500 in Fall 2021.