﻿```
 Author:   Sasha Singh
Partner:   None
Date:      30-Jan-2022 to Feb-4-2022
Course:    CS 3500, University of Utah, School of Computing
GitHub ID: SashaSingh2000
Repo:      https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000
Commit #:  bf838582ef9ddd48c53ea6cddb4996d384d6f9d7
Project:   Formula
Copyright: CS 3500 and Sasha Singh - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators + Assignment Specific Implementation:

1. This Test class contains a mix of test methods for Evaluation of simple and complex formulas with
and without variables, normalized variables, equality as Equals and ==, hashcode equality,
toString equality, doubles/ints/floating points/scientfic notations, Formula Errors, 
FormulaFormatExceptions, Division by Zero, WhiteSpaces, Nulls, Constructor, != operator, isValid,
and more to achieve 100 percent code coverage.

Some of these tests were adopted from various Piazza posts, formula exampled discussed in class,
with TA's, and from Dr. Daniel Kopta's examples.

2. I had some issues running all tests together, they run individually but not 
together. Is this a compliler problem? Cleaned and rebuilt my solution to try and fix 
this on my own. 
GetHashCode was having some issues with running, realized I needed to convert it to 
a String to be able to compare. 
The == operator tests are failing currently, 
Evaluate is throwing the right errors, they just need to be Formula Errors instead
of ArguementExceptions.

3. I spoke with Dr. de St Germain on Feburary 8th, 2022 at 5 pm around my implementation of some tests in FormulaTests class.
We spoke about some course material I had used from Dr. Daniel Kopta from Fall 2021 class. There are a few instances of tests that were directly discussed in class and other
help that I adopted. All those links are specifically stated in this README now. Dr.Germain has advised me to in the future always clearly state where the tests are coming from
and be marked in the tester file itself. I will make sure t do this moving forward.

4. I have now copied over all grading tests for Formula, and am currently failing 5 of them. I will work to get those fixed and move forward with A4.

# Consulted Peers:


# References:

1.Dr. Kopta's Week 4 Lecture - https://utah.instructure.com/courses/717551/pages/week-4-lectures?module_item_id=15979599
2.Code Coverage Report- file:///C:/Users/u0982683/source/repos/Utah-School-of-Computing-de-St-Germain/spreadsheet-SashaSingh2000/FormulaTests/coveragereport/Formula_Formula.html
3.Dr.Kopta's course material- https://utah.instructure.com/courses/717551/pages/week-3-lectures?module_item_id=15926782\, https://utah.instructure.com/courses/717551/pages/week-4-lectures?module_item_id=15979599
4.U of U Fall 2021 Repository- https://github.com/uofu-cs3500-fall21/Examples/


# Time Spent:

    Time Spent testing -
    Feburary 2nd- 2 hours
    Feburary 3rd - 4 hours
